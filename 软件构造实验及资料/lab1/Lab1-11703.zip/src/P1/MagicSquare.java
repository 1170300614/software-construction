package P1;

import java.io.*;
import java.util.*;

public class MagicSquare {
	public static boolean isLegalMagicSquare(String fileName) {
		
		String filename = "src/P1/txt/" + fileName;//�����ļ�·����ע
        String encoding = "UTF-8";//�ַ���������
        String content = null;
        File file = new File(filename);//�ļ�����
        Long filelongth = file.length();
        byte[] filecontent = new byte[filelongth.intValue()];
        int cols = 0 , rows = 0;//��������
        
        try{
            FileInputStream in = new FileInputStream(file);
            in.read(filecontent);
            in.close();
        }catch(FileNotFoundException e){
            e.printStackTrace();
        }catch(IOException e){
            e.printStackTrace();
        }//�ļ���д����
        
        try{
            content = new String(filecontent,encoding);
        }catch(UnsupportedEncodingException e){
            System.err.println("The OS does not support " + encoding);//ʵʱ���
            e.printStackTrace();
        }
        String line[] = content.split("\n");
                 rows = line.length;    //the rows of the square
                 cols = rows;
                int nums[][] = new int[rows][rows];
                int sumR[] = new int[rows];//���к�
                int sumC[] = new int[cols];//���к�
                int sumD[] = new int[2];//�Խ��ߺ�
                //Ĭ�ϳ�ʼ��Ϊ0
                 
                for(int i = 0; i < rows;i++)//�����ݽ��д������ж����ݵĺϷ��Բ������ֵ
                {
        
                    if(line[i].split(".").length != 0)//��.���ж��Ƿ���С��
                   {
                        System.out.println("���ݴ��ڸ�����");
                        return false;
                    }

           if(line[i].split("-").length > 1)//���ݸ������ж��Ƿ��и���
            {
                System.out.println("���ݴ��ڸ���");
                 return false;
            }
           
             String []data = line[i].split("\t");//���ݷ����ж�
             
                    if(data.length != rows)
                    {
                        if(i == 0)
                            System.out.println("�����������");
                        else
                            System.out.println("��Ϊ����");
                        return false;
                    }
                    
                    for(int j = 0; j < rows ;j++)
                    {
                        try{
                            int num = Integer.valueOf(data[j]).intValue();
                          nums[i][j]=num;
                        }catch(NumberFormatException e){
                            System.out.println("�����д��ڷǷ�����");
                            return false;
                        }
                        
                        sumR[i] += nums[i][j];
                        sumC[j] += nums[i][j];
                        
                        if(i == j)
                        {
                            sumD[0] += nums[i][j];
                        }
                        
                        if(i + j +1 == cols)
                        {
                            sumD[1] += nums[i][j];
                       }
             }
         }
         
         if(sumD[0] != sumD[1])
         {
            return false;
         }
          
        int sum = sumD[0];
        
        for(int i = 0; i<rows; i++)
         {
             if(sumR[i] != sum || sumC[i] != sum)
                  return false;
         }
        
        return true;
	}
	public static boolean generateMagicSquare(int n) { //�Զ����ɻ÷�
		File file = new File("src/P1/txt/6.txt");
		
		int magic[][] = new int[n][n];
		int row = 0, col = n / 2, i, j, square = n * n;
		
		for (i = 1; i <= square; i++) {
			magic[row][col] = i;
			if (i % n == 0)
				row++;
			else {
				if (row == 0)
					row = n - 1;
				else
					row--;
				if (col == (n - 1))
					col = 0;
				else
					col++;
			}
		}
		try{
					FileOutputStream out = new FileOutputStream(file);
		for (i = 0; i < n; i++) {
			for (j = 0; j < n; j++) {
				System.out.print(magic[i][j] + "\t");
				
					
					String s = String.valueOf(magic[i][j]);
					byte a[] = s.getBytes();
					out.write(a);
				    out.write('\t');
			}
			out.write('\n');
			System.out.println();
		}
		out.close();
		}catch(Exception e) {
					e.printStackTrace();
				}//�ļ���д����
		
		return true;
		
	}
		public static void main(String args[]){
		    MagicSquare magic = new MagicSquare();
		    for(int i = 1 ; i<6 ; i++)
		    {
		        if(magic.isLegalMagicSquare(String.valueOf(i)+".txt"))//�����ı����в��ԣ�ת��Ϊ�ַ���ʹ������ȷ
		            System.out.println(i+":Yes");
		        else{
		            System.out.println(i+":No");
		        }
		    }
		    int n;
		    Scanner in = new Scanner(System.in);
		    n = in.nextInt();
		    System.out.println(magic.generateMagicSquare(n));
		    if(magic.isLegalMagicSquare("6.txt"))//���ԣ�ת��Ϊ�ַ���ʹ������ȷ
	            System.out.println(6+":Yes");
	        else{
	            System.out.println(6+":No");
	        }
		}
	}

