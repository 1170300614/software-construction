package P3;

import java.nio.channels.Pipe;
import java.util.ArrayList;
import java.util.LinkedList;
import java.util.List;
import java.util.Queue;

import org.omg.IOP.ENCODING_CDR_ENCAPS;

public class FriendshipGraph {
	private int i=0, j=0;
	public List<Person> Vertex = new ArrayList<Person>(); //list�����,ʹ���ٽ����

	public void addVertex(Person p) {
		for(i = 0; i < Vertex.size(); ++i) {
			if(Vertex.get(i).name == p.name) {
				System.out.println("Wrong input, " + p.name);
				System.exit(0);
			}
			
		}
		Vertex.add(p);
		p.num = Vertex.size() - 1;   //���ñ��
	}
	public void addEdge(Person p1, Person p2) {
		//edge[p1.num][p2.num] = 1;   //�ӱ�, �˴�Ϊ����ͼ�ӱ�, ���Լ�����
		//edge[p2.num][p1.num] = 1;
		p1.friends.add(p2);
	}
	public int getDistance(Person p1, Person p2) {
		int i;
		for(i = 0; i < Vertex.size(); ++i)  //��ʼ���flagȫ����Ϊû���ʹ�
			Vertex.get(i).flag = false;
		for(Person p: Vertex) {
			p.dist = 0;
		}
		//int [] dist = new int[10000];      //dist����洢ÿ���㵽�涨������̾���
		//List <Integer> dist = new ArrayList<Integer>();
		Queue<Person> queue = new LinkedList<Person>();
		queue.add(p1);
		p1.flag = true;
		if(p1.equals(p2)) {
			return 0;
		}
		while (!queue.isEmpty()) {      //���ù���
			for(Person p: queue.peek().friends) {
				if(p.flag == false) {
					queue.add(p);
					p.flag = true;
//					Person t=Vertex.get(i);
//					t.flag = true;
//					Vertex.set(i, t);
					p.dist = queue.peek().dist + 1;
					if(p.equals(p2)) {
						return p.dist;
					}
				}
			}
			queue.remove();
		}
//		return dist[p2.num];
		return -1;   //�Ҳ���·�ͷ��� -1
	}
	
	public static void main(String[] args) {
			FriendshipGraph graph = new FriendshipGraph();
			Person rachel = new Person("Rachel");
			Person ross = new Person("Ross");
			Person ben = new Person("Ben");
			Person kramer = new Person("Kramer");
			graph.addVertex(rachel);
			graph.addVertex(ross);
			graph.addVertex(ben);
			graph.addVertex(kramer);
			graph.addEdge(rachel, ross);
			graph.addEdge(ross, rachel);
			graph.addEdge(ross, ben);
			graph.addEdge(ben, ross);
			System.out.println(graph.getDistance(rachel, ross)); 
		//should print 1
			System.out.println(graph.getDistance(rachel, ben)); 
		//should print 2
			System.out.println(graph.getDistance(rachel, rachel)); 
		//should print 0
			System.out.println(graph.getDistance(rachel, kramer)); 
		//should print -1
		

	}
	
}