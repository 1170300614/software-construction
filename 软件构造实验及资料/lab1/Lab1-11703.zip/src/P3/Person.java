package P3;

import java.util.ArrayList;
import java.util.List;

public class Person {
	protected String name;   //����
	protected boolean flag = false; //���ʱ�־
	protected int num; //���
	public List<Person> friends = new ArrayList<Person>();   //�洢�˼ʹ�ϵ
	protected int dist;
	public Person(String s) {
		this.name = s;
		dist = 0;
	}
}