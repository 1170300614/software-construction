package P2;

import P1.src.graph.Graph;

import java.util.ArrayList;
import java.util.LinkedList;
import java.util.List;
import java.util.Queue;
import java.util.stream.Collectors;

class Main{
    public static void main(String[] args){
        FriendshipGraph graph = new FriendshipGraph();

        Person rachel = new Person("Rachel");
        Person ross = new Person("Ross");
        Person ben = new Person("Ben");
        Person kramer = new Person("Kramer");

        graph.addVertex(rachel);
        graph.addVertex(ross);
        graph.addVertex(ben);
        graph.addVertex(kramer);
        //graph.addVertex(ross);
        graph.addEdge(rachel, ross);
        graph.addEdge(ross, rachel);
        graph.addEdge(ross, ben);
        graph.addEdge(ben, ross);
        System.out.println(graph.getDistance(rachel, ross));
        //should print 1
        System.out.println(graph.getDistance(rachel, ben));
        //should print 2
        System.out.println(graph.getDistance(rachel, rachel));
        //should print 0
        System.out.println(graph.getDistance(rachel, kramer));
        //should print -1
    }
}

/**
 * The class FrinedshipGraph includes the methods of the graph
 */
class FriendshipGraph{
    Graph<Person> graph = Graph.empty();
    List<String> nameList = new ArrayList<>();
    int num = 0;

    public void addVertex(Person person){
        for(String i: nameList)
            if(person.getName().equals(i)){
                System.out.print("Each person has an unique name. EXIT...");
                System.exit(1);
            }

        nameList.add(person.getName());
        graph.add(person);
        num++;
    }

    public void addEdge(Person person_1, Person person_2){
        graph.set(person_1, person_2, 1);
    }

    public int getDistance(Person person_1, Person person_2){
        if(person_1 == person_2)
            return 0;

        for(Person person: graph.vertices()){
            person.notVisited();
            person.setDistance(0);
        }

        Queue<Person> queue = new LinkedList<>();
        queue.add(person_1);
        person_1.visited();

        while(!queue.isEmpty()){
            Person v = queue.poll();
            v.visited();

            for(Person person: graph.targets(v).keySet().stream().filter(person->!person.getVisited()).collect(
                    Collectors.toSet())){
                if(person == person_2)
                    return v.getDistance() + 1;

                if(!person.getVisited()){
                    person.setDistance(v.getDistance() + 1);
                    person.visited();
                    queue.add(person);
                }
            }
        }

        return -1;
    }
}