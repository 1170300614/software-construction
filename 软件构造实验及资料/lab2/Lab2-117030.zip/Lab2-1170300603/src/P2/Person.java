package P2;

public class Person{
    private String name;
    private Boolean visited;
    private int distance;

    public Person(String name){
        this.name = name;
        this.visited = false;
        this.distance = 0;
    }

    public void visited(){
        this.visited = true;
    }

    public void notVisited(){
        this.visited = false;
    }

    public void setDistance(int distance){
        this.distance = distance;
    }

    public String getName(){
        return this.name;
    }

    public Boolean getVisited(){
        return this.visited;
    }

    public int getDistance(){
        return this.distance;
    }
}