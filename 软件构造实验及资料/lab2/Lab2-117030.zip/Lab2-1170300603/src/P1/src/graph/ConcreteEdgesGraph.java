/* Copyright (c) 2015-2016 MIT 6.005 course staff, all rights reserved.
 * Redistribution of original or derived work requires permission of course staff.
 */
package P1.src.graph;

import java.util.*;
import java.util.function.Predicate;
import java.util.stream.Collectors;

/**
 * An implementation of Graph.
 *
 * <p>PS2 instructions: you MUST use the provided rep.
 */
public class ConcreteEdgesGraph<L> implements Graph<L>{

    private final Set<L> vertices = new HashSet<>();
    private final List<Edge<L>> edges = new ArrayList<>();

    // Abstraction function:
    public ConcreteEdgesGraph(){
    }
    // Representation invariant:
    //   TODO
    // Safety from rep exposure:
    //   TODO

    // TODO constructor

    // TODO checkRep
    //The maximum number of edges in a n-vertex simple graph is ceil(sqrt(2 * sizeOfEdges) + 0.5)
    private void checkRep(){
        final int sizeOfEdges = edges.size();
        final int sizeOfVertices = vertices.size();
        int minNumberOfVertices = sizeOfEdges == 0 ? 0 : (int) Math.ceil(Math.sqrt(2 * sizeOfEdges) + 0.5);

        assert sizeOfVertices >= minNumberOfVertices;
    }

    @Override
    public boolean add(L vertex){
        return vertices.add(vertex);
    }

    @Override
    public int set(L source, L target, int weight){
        int indexOfEdge = indexOfEdge(source, target);
        int previousWeight = 0;
        Edge<L> previousEdge;

        if(weight > 0){
            Edge<L> newEdge = new Edge<>(source, target, weight);
            if(indexOfEdge < 0){
                add(source);
                add(target);
                edges.add(newEdge);
            }else{
                previousEdge = edges.set(indexOfEdge, newEdge);
                previousWeight = previousEdge.getWeight();
            }
        }else if(weight == 0 && indexOfEdge >= 0){
            previousEdge = edges.remove(indexOfEdge);
            previousWeight = previousEdge.getWeight();
        }

        checkRep();
        return previousWeight;
    }

    @Override
    public boolean remove(L vertex){
        int initialSizeOfEdges = edges.size();
        int initialSizeOfVertices = vertices.size();
        Predicate<L> vertexInVertices = v->v.equals(vertex);
        Predicate<Edge<L>> edgeInEdges = (Edge<L> edge)->(edge.getSource().equals(vertex) || edge.getTarget().equals(
                vertex));

        boolean removedVertice = vertices.removeIf(vertexInVertices);
        boolean removedEdge = edges.removeIf(edgeInEdges);

        if(removedVertice){
            assert initialSizeOfVertices != vertices.size();
            assert initialSizeOfVertices - 1 == vertices.size();
        }
        if(removedEdge)
            assert initialSizeOfEdges != edges.size();

        checkRep();
        return initialSizeOfVertices - 1 == vertices.size();
    }

    @Override
    public Set<L> vertices(){
        return vertices;
    }

    @Override
    public Map<L, Integer> sources(L target){
        return edges.stream().filter(edge->edge.getTarget().equals(target)).collect(
                Collectors.toMap(Edge::getSource, Edge::getWeight));
    }

    @Override
    public Map<L, Integer> targets(L source){
        return edges.stream().filter(edge->edge.getSource().equals(source)).collect(
                Collectors.toMap(Edge::getTarget, Edge::getWeight));
    }

    @Override
    public String toString(){
        if(edges.isEmpty())
            return "Empty graph";

        return edges.stream().map(edge->edge.toString()).collect(Collectors.joining("->"));
    }

    //To get the index of the edge in the List
    private int indexOfEdge(L source, L target){
        for(int i = 0; i < edges.size(); i++){
            Edge<L> edge = edges.get(i);
            if(edge.getSource().equals(source) && edge.getTarget().equals(target))
                return i;
        }

        return -1;
    }
}

/**
 * TODO specification
 * Immutable.
 * This class is internal to the rep of ConcreteEdgesGraph.
 *
 * <p>PS2 instructions: the specification and implementation of this class is
 * up to you.
 */
class Edge<L>{
    // TODO fields
    private final L source;
    private final L target;
    private final int weight;
    // Abstraction function:
    //   TODO
    // Representation invariant:
    //   TODO
    // Safety from rep exposure:
    //   TODO

    // TODO constructor
    public Edge(final L source, final L target, final int weight){
        assert weight > 0;
        this.source = source;
        this.target = target;
        this.weight = weight;
        checkRep();
    }

    // TODO checkRep
    private void checkRep(){
        assert source != null;
        assert target != null;
        assert weight > 0;
    }

    // TODO methods
    public L getSource(){
        return source;
    }

    public L getTarget(){
        return target;
    }

    public int getWeight(){
        return weight;
    }

    public Edge<L> setWeight(int newWeight){
        checkRep();
        return new Edge<>(source, target, newWeight);
    }
    // TODO toString()

    @Override
    public String toString(){
        return getSource().toString() + " -> " + getTarget().toString() + ": " + getWeight();
    }

    @Override
    public boolean equals(Object that){
        if(!(that instanceof Edge))
            return false;

        Edge<?> thatEdge = (Edge<?>) that;
        return this.getSource().equals(thatEdge.getSource()) && this.getTarget().equals(
                thatEdge.getTarget()) && this.getWeight() == thatEdge.getWeight();
    }

    @Override
    public int hashCode(){
        final int prime = 7;
        int result = 1;

        result = prime * result + getSource().hashCode();
        result = prime * result + getTarget().hashCode();
        result = prime * result + getWeight();

        return result;
    }
}