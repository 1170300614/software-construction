/* Copyright (c) 2015-2016 MIT 6.005 course staff, all rights reserved.
 * Redistribution of original or derived work requires permission of course staff.
 */
package P1.src.graph;

import java.util.*;
import java.util.stream.Collectors;

/**
 * An implementation of Graph.
 *
 * <p>PS2 instructions: you MUST use the provided rep.
 */
public class ConcreteVerticesGraph<L> implements Graph<L>{

    private final List<Vertex<L>> vertices = new ArrayList<>();

    // Abstraction function:
    //   TODO
    // Representation invariant:
    //   TODO
    // Safety from rep exposure:
    //   TODO

    // TODO constructor
    public ConcreteVerticesGraph(){
    }

    // TODO checkRep
    private void checkRep(){
        assert vertices().size() == vertices.size();
    }

    @Override
    public boolean add(L vertex){
        if(vertices().contains(vertex))
            return false;

        Vertex<L> newVertex = new Vertex<>(vertex);
        boolean isAdded = vertices.add(newVertex);

        checkRep();
        return isAdded;
    }

    @Override
    public int set(L source, L target, int weight){
        Vertex<L> sourceVertex;
        Vertex<L> targetVertex;
        Set<L> verticeLabels = vertices();

        if(verticeLabels.contains(source)){
            int sourceIndex = indexOfVertices(source);
            sourceVertex = vertices.get(sourceIndex);
        }else{
            sourceVertex = new Vertex<>(source);
            vertices.add(sourceVertex);
        }

        if(verticeLabels.contains(target)){
            int targetIndex = indexOfVertices(target);
            targetVertex = vertices.get(targetIndex);
        }else{
            targetVertex = new Vertex<>(target);
            vertices.add(targetVertex);
        }

        int previousSourceWeight = sourceVertex.setTarget(target, weight);
        int previousTargetWeight = targetVertex.setSource(source, weight);

        assert previousSourceWeight == previousTargetWeight;
        checkRep();
        return previousSourceWeight;
    }

    @Override
    public boolean remove(L vertex){
        if(!vertices().contains(vertex))
            return false;

        for(Vertex<L> v: vertices)
            v.remove(vertex);

        checkRep();
        return true;
    }

    @Override
    public Set<L> vertices(){
        return vertices.stream().map(Vertex::getLabel).collect(Collectors.toSet());
    }

    @Override
    public Map<L, Integer> sources(L target){
        int targetIndex = indexOfVertices(target);
        if(targetIndex < 0)
            return Collections.emptyMap();

        return vertices.get(targetIndex).getSources();
    }

    @Override
    public Map<L, Integer> targets(L source){
        final int sourceIndex = indexOfVertices(source);
        if(sourceIndex < 0)
            return Collections.emptyMap();

        return vertices.get(sourceIndex).getTargets();
    }

    // TODO toString()

    @Override
    public String toString(){
        if(vertices.isEmpty())
            return  "Empty graph";
        return vertices.stream().filter(vertex->vertex.getTargets().size() > 0).map(
                vertex->vertex.getLabel().toString() + " -> " + vertex.getTargets()).collect(Collectors.joining(" "));
    }

    private int indexOfVertices(L label){
        for(int i = 0; i < vertices.size(); i++)
            if(vertices.get(i).getLabel().equals(label))
                return i;

        return -1;
    }
}

/**
 * TODO specification
 * Mutable.
 * This class is internal to the rep of ConcreteVerticesGraph.
 *
 * <p>PS2 instructions: the specification and implementation of this class is
 * up to you.
 */
class Vertex<L>{

    // TODO fields
    private final L label;
    private final Map<L, Integer> sources = new HashMap<>();
    private final Map<L, Integer> targets = new HashMap<>();
    // Abstraction function:
    //   TODO
    // Representation invariant:
    //   TODO
    // Safety from rep exposure:
    //   TODO

    // TODO constructor
    public Vertex(final L label){
        this.label = label;
    }

    // TODO checkRep
    private void checkRep(){
        Set<L> sourceLabels = sources.keySet();
        Set<L> targetLabels = targets.keySet();

        assert !sourceLabels.contains(this.label);
        assert !targetLabels.contains(this.label);
    }

    // TODO methods

    public L getLabel(){
        return label;
    }

    public Map<L, Integer> getSources(){
        return sources;
    }

    public Map<L, Integer> getTargets(){
        return targets;
    }

    private void checkInputLabel(L inputLabel){
        assert inputLabel != null;
    }

    public boolean addSource(L source, int weight){
        checkInputLabel(source);
        assert weight > 0;

        if(sources.putIfAbsent(source, weight) == null){
            checkRep();
            return true;
        }
        return false;
    }

    public boolean addTarget(L target, int weight){
        checkInputLabel(target);
        assert weight > 0;

        if(targets.putIfAbsent(target, weight) == null){
            checkRep();
            return true;
        }
        return false;
    }

    public int remove(L vertex){
        checkInputLabel(vertex);
        int previousSourceWeight = removeSource(vertex);
        int previousTargetWeight = removeTarget(vertex);

        if(previousSourceWeight > 0 && previousTargetWeight > 0){
            assert previousSourceWeight == previousTargetWeight;
        }
        return previousSourceWeight == 0 ? previousTargetWeight : previousSourceWeight;
    }

    public int removeSource(L source){
        checkInputLabel(source);
        Integer previousWeight = sources.remove(source);

        checkRep();
        return previousWeight == null ? 0 : previousWeight;
    }

    public int removeTarget(L target){
        checkInputLabel(target);
        Integer previousWeight = targets.remove(target);

        checkRep();
        return previousWeight == null ? 0 : previousWeight;
    }

    public int setSource(L source, int weight){
        checkInputLabel(source);
        assert weight >= 0;
        int previousWeight;

        if(weight == 0)
            previousWeight = removeSource(source);
        else if(addSource(source, weight) || sources.get(source).equals(weight))
            previousWeight = 0;
        else
            previousWeight = sources.replace(source, weight);

        checkRep();
        return previousWeight;
    }

    public int setTarget(L target, int weight){
        checkInputLabel(target);
        assert weight >= 0;
        int previousWeight;

        if(weight == 0)
            previousWeight = removeTarget(target);
        else if(addTarget(target, weight) || targets.get(target).equals(weight))
            previousWeight = 0;
        else
            previousWeight = targets.replace(target, weight);

        checkRep();
        return previousWeight;
    }

    // TODO toString()
    @Override
    public String toString(){
        return String.format("%s -> %s \n" + "%s <- %s", this.label.toString(), this.targets, this.label.toString(),
                this.sources);
    }
}