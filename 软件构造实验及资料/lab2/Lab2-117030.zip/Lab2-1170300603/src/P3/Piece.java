package P3;
public class Piece extends Position{
    private String playerName;
    private Boolean status = false;
    private String name;
    private int code;

    public Piece(){
        this.playerName = "Player";
        this.status = false;
        this.name = "Default";
        this.code = 1;
        this.setX(-1);
        this.setY(-1);
    }

    public Piece(Player player, String name, int code, Boolean status){
        this.playerName = player.getName();
        this.name = name;
        this.code = code;
        this.status = status;
    }

    public void setPiece(Player player, String name, int code, Boolean status, int x, int y){
        this.playerName = player.getName();
        this.name = name;
        this.code = code;
        this.status = status;
        setX(x);
        setY(y);
    }

    public void setPlayer(Player player){
        this.playerName = player.getName();
    }

    public void setKind(String name, int code){
        this.name = name;
        this.code = code;
    }

    public void setStatus(Boolean status){
        this.status = status;
    }

    public int getCode(){
        return code;
    }

    public String getName(){
        return name;
    }

    public Boolean getStatus(){ return status;
    }

    public String getPlayerName(){
        return playerName;
    }
}