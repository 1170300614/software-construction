package P3;
public class Game{
    private String name;
    private String kind;

    public Game(){

    }

    public Game(String name, String kind){
        this.name = name;
        this.kind = kind;
    }

    public void setName(String name){
        this.name = name;
    }

    public void setKind(String kind){
        this.kind = kind;
    }

    public String getName(){
        return this.name;
    }

    public String getKind(){
        return this.kind;
    }
}