package P3;

public class Board{
    private int size;
    private String name;
    private String kind;

    public Board(){

    }

    public Board(int size){
        this.size = size;
        this.name = "default";
        this.kind = "grid";
    }

    public Board(int size, String name){
        this.size = size;
        this.name = name;
        this.kind = "grid";
    }

    public Board(int size, String name, String kind){
        this.size = size;
        this.name = name;
        this.kind = kind;
    }

    public String getName(){
        return name;
    }

    public int getSize(){
        return size;
    }

    public String getKind(){
        return kind;
    }

    public void displayChess(Piece[] pieces){
        for(Piece piece: pieces)
            if(piece.getStatus())
                System.out.println(
                        piece.getPlayerName() + "_" + piece.getName() + "." + piece.getCode() + " " + "(" + piece.getX() + ", " + piece.getY() + ")");
    }

    public void displayGo(Piece[] pieces){
        for(Piece piece: pieces)
            if(piece.getStatus())
                System.out.println(
                        piece.getPlayerName() + "_" + piece.getName() + "." + piece.getCode() + " " + "(" + piece.getX() + ", " + piece.getY() + ")");
    }

    public void setSize(int size){
        this.size = size;
    }

    public void setName(String name){
        this.name = name;
    }

    public void setKind(String kind){
        this.kind = kind;
    }

    public Piece[] generatePieces(Player player1, Player player2){
        if(kind.equals("grid")){
            Piece[] chess = new Piece[32];
            for(int i = 0; i < 32; i++)
                chess[i] = new Piece();
            chess[0].setPiece(player1, "king", 1, true, 3, 0);
            chess[1].setPiece(player1, "queen", 1, true, 4, 0);
            chess[2].setPiece(player1, "rook", 1, true, 0, 0);
            chess[3].setPiece(player1, "rook", 2, true, 7, 0);
            chess[4].setPiece(player1, "bishop", 1, true, 2, 0);
            chess[5].setPiece(player1, "bishop", 2, true, 5, 0);
            chess[6].setPiece(player1, "knight", 1, true, 1, 0);
            chess[7].setPiece(player1, "knight", 2, true, 6, 0);
            chess[8].setPiece(player1, "pawn", 1, true, 0, 1);
            chess[9].setPiece(player1, "pawn", 2, true, 1, 1);
            chess[10].setPiece(player1, "pawn", 3, true, 2, 1);
            chess[11].setPiece(player1, "pawn", 4, true, 3, 1);
            chess[12].setPiece(player1, "pawn", 5, true, 4, 1);
            chess[13].setPiece(player1, "pawn", 6, true, 5, 1);
            chess[14].setPiece(player1, "pawn", 7, true, 6, 1);
            chess[15].setPiece(player1, "pawn", 8, true, 7, 1);
            chess[16].setPiece(player2, "king", 1, true, 3, 7);
            chess[17].setPiece(player2, "queen", 1, true, 4, 7);
            chess[18].setPiece(player2, "rook", 1, true, 0, 7);
            chess[19].setPiece(player2, "rook", 2, true, 7, 7);
            chess[20].setPiece(player2, "bishop", 1, true, 2, 7);
            chess[21].setPiece(player2, "bishop", 2, true, 5, 7);
            chess[22].setPiece(player2, "knight", 1, true, 1, 7);
            chess[23].setPiece(player2, "knight", 2, true, 6, 7);
            chess[24].setPiece(player2, "pawn", 1, true, 0, 6);
            chess[25].setPiece(player2, "pawn", 2, true, 1, 6);
            chess[26].setPiece(player2, "pawn", 3, true, 2, 6);
            chess[27].setPiece(player2, "pawn", 4, true, 3, 6);
            chess[28].setPiece(player2, "pawn", 5, true, 4, 6);
            chess[29].setPiece(player2, "pawn", 6, true, 5, 6);
            chess[30].setPiece(player2, "pawn", 7, true, 6, 6);
            chess[31].setPiece(player2, "pawn", 8, true, 7, 6);

            return chess;
        }else if(kind.equals("cross")){
            Piece[] go = new Piece[360];
            for(int i = 0; i < 360; i++)
                go[i] = new Piece();
            for(int i = 0; i < 180; i++)
                go[i].setPiece(player1, "white", i + 1, false, -1, -1);
            for(int i = 180; i < 360; i++)
                go[i].setPiece(player2, "black", i + 1, false, -1, -1);

            return go;
        }

        Piece[] pieces = new Piece[1];
        return pieces;
    }

    public Boolean checkChessMoveAllowed(Piece[] pieces, Piece current, int x, int y){

        if(!current.getStatus()){
            System.out.println("The chess has been attacked.");
            return false;
        }else if(x < 0 || x >= size || y < 0 || y >= size){
            System.out.println("Out of board");
            return false;
        }else if(current.getX() == x && current.getY() == y){
            System.out.println("Can't set the chess to the same location.");
            return false;
        }else{
            for(Piece piece: pieces)
                if(piece.getStatus() && piece.getPlayerName().equals(
                        current.getPlayerName()) && piece.getX() == x && piece.getY() == y){
                    System.out.println("Can't move the chess to own chesses");
                    return false;
                }

            return true;
        }
    }

    public Boolean checkGoMoveAllowed(Piece[] pieces, Piece current, int x, int y){
        if(current.getStatus()){
            System.out.println("Can't move used chess.");
            return false;
        }else if(current.getX() == x && current.getY() == y){
            System.out.println("Can't set the chess to the same location.");
            return false;
        }else if(x < 0 || x >= size || y < 0 || y >= size){
            System.out.println("Out of board");
            return false;
        }else
            for(Piece piece: pieces){
                if(piece.getStatus() && piece.getX() == x && piece.getY() == y){
                    System.out.println("Can't move the chess to used location");
                    return false;
                }
            }

        return true;
    }

    public Boolean isGameOver(Game game, Piece[] pieces){
        if(game.getKind().equals("chess")){
            for(int i = 0; i < 16; i++){
                if(pieces[i].getStatus())
                    break;
                else if(i == 15){
                    System.out.println("Player 1 lose.");
                    return true;
                }
            }

            for(int i = 16; i < 32; i++){
                if(pieces[i].getStatus())
                    break;
                else if(i == 31){
                    System.out.println("Player 2 lose.");
                    return true;
                }
            }
        }

        return false;
    }
}