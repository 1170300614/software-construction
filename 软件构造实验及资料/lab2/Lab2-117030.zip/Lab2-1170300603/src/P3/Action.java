package P3;

public interface Action{
    public Boolean moveChess(Board board, Piece[] pieces, Piece current, int x, int y);

    public Boolean moveGo(Board board, Piece[] pieces, Piece current, int x, int y);

    public Piece selectChess(Piece[] pieces, Player player, String name, int code);

    public Piece selectGo(Piece[] pieces, Player player);
}
