package P3;

public class Player implements Action{
    private String name;
    private int step;

    public Player(String name){
        this.name = name;
        this.step = 0;
    }

    public String getName(){
        return name;
    }

    public void setName(String name){
        this.name = name;
    }

    public Boolean giveUp(){
        return false;
    }

    public Boolean moveChess(Board board, Piece[] pieces, Piece current, int x, int y){
        if(board.checkChessMoveAllowed(pieces, current, x, y)){
            current.setX(x);
            current.setY(y);
            System.out.println(
                    current.getPlayerName() + "'s " + current.getName() + "_" + current.getCode() + " moved to " + board.getKind() + "(" + x + ", " + y + ")");

            for(Piece piece: pieces){
                if(piece.getX() == x && piece.getY() == y && piece.getStatus() && !piece.getPlayerName().equals(
                        current.getPlayerName())){
                    piece.setStatus(false);
                    System.out.println(
                            piece.getPlayerName() + "'s " + piece.getName() + piece.getCode() + " has been attacked by " + current.getPlayerName() + "'s " + current.getName() + current.getCode());
                    break;
                }
            }
        }else
            return false;

        return true;
    }

    public Boolean moveGo(Board board, Piece[] pieces, Piece current, int x, int y){
        if(board.checkGoMoveAllowed(pieces, current, x, y)){
            current.setX(x);
            current.setY(y);
            current.setStatus(true);

            System.out.println(
                    current.getPlayerName() + "'s " + current.getName() + "_" + current.getCode() + " move to " + board.getKind() + "(" + x + ", " + y + ")");
            return true;
        }else
            current.setStatus(false);

        return false;
    }

    public Boolean hasChess(Piece[] pieces, Player player, String name, int code){
        for(Piece piece: pieces)
            if(piece.getName().equals(name) && piece.getPlayerName().equals(
                    player.getName()) && piece.getCode() == code)
                return true;

        return false;
    }

    public Boolean hasGo(Piece[] pieces, Player player){
        for(Piece piece: pieces)
            if(!piece.getStatus() && piece.getPlayerName().equals(player.getName()))
                return true;

        return false;
    }

    public Piece selectChess(Piece[] pieces, Player player, String name, int code){
        Piece piece1 = new Piece();

        for(Piece piece: pieces)
            if(piece.getName().equals(name) && piece.getPlayerName().equals(
                    player.getName()) && piece.getCode() == code)
                return piece;

        return piece1;
    }

    public Piece selectGo(Piece[] pieces, Player player){
        Piece piece2 = new Piece();

        for(Piece piece: pieces)
            if(!piece.getStatus() && piece.getPlayerName().equals(player.getName()))
                return piece;

        return piece2;
    }
}