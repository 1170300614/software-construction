package P3;

import java.util.Scanner;

public class MyChessAndGoGame{
    public static void main(String[] args){
        Scanner in = new Scanner(System.in);
        int choice = 0;
        int count = 1;

        Game game = new Game();

        System.out.println("Enter the name of the player1.");
        String name = in.next();
        Player player1 = new Player(name);
        System.out.println("Enter the name of the player2.");
        name = in.next();
        Player player2 = new Player(name);

        Board board = new Board();

        try{
            System.out.println("CHESS [0]");
            System.out.println("GO [1]");
            choice = in.nextInt();
        }
        catch(Exception e){
            e.printStackTrace();
        }

        if(choice == 0){
            board.setSize(8);
            board.setName("CHESS BOARD");
            board.setKind("grid");
            game.setName("NAME");
            game.setKind("chess");
            Piece[] pieces = board.generatePieces(player1, player2);
            while(!board.isGameOver(game,
                    pieces)){//!board.isGameOver(game,pieces) || player1.giveUp() || player2.giveUp()){
                System.out.println("Round " + count);
                System.out.println(player1.getName());
                System.out.println("Input the chess's name and chess's code. Then input the target location (x, y).");
                String chessName = in.next();
                int chessCode = in.nextInt();
                int x = in.nextInt();
                int y = in.nextInt();
                if(player1.hasChess(pieces, player1, chessName, chessCode)){
                    if(!player1.moveChess(board, pieces, player1.selectChess(pieces, player1, chessName, chessCode), x,
                            y))
                        continue;
                    else
                        board.displayChess(pieces);
                }else{
                    System.out.println("Not exist.");
                    continue;
                }
                System.out.println(player2.getName());
                System.out.println("Input the chess's name and chess's code. Then input the target location (x, y).");
                chessName = in.next();
                chessCode = in.nextInt();
                x = in.nextInt();
                y = in.nextInt();
                if(player2.hasChess(pieces, player2, chessName, chessCode)){
                    if(!player2.moveChess(board, pieces, player2.selectChess(pieces, player2, chessName, chessCode), x,
                            y))
                        System.out.println("Can not move to the same location.");
                    else
                        board.displayChess(pieces);
                }else{
                    System.out.println("Not exist.");
                    continue;
                }

                count++;
            }
        }else{
            board.setSize(19);
            board.setName("GO BOARD");
            board.setKind("cross");
            game.setName("GAME");
            game.setKind("go");
            Piece[] pieces = board.generatePieces(player1, player2);
            while(true){
                System.out.println("Round " + count);
                System.out.println(player1.getName());
                System.out.println("Input the target location (x, y).");
                int x = in.nextInt();
                int y = in.nextInt();
                if(player1.hasGo(pieces, player1)){
                    if(!player1.moveGo(board, pieces, player1.selectGo(pieces, player1), x, y))
                        continue;
                    else
                        board.displayGo(pieces);
                }else{
                    System.out.println("No chess. GAME OVER");
                    break;
                }
                System.out.println(player2.getName());
                System.out.println("Input the target location (x, y).");
                x = in.nextInt();
                y = in.nextInt();
                if(player2.hasGo(pieces, player2)){
                    if(!player2.moveGo(board, pieces, player2.selectGo(pieces, player2), x, y))
                        continue;
                    else
                        board.displayGo(pieces);
                }else{
                    System.out.println("No chess. GAME OVER");
                    break;
                }

                count++;
            }
        }
    }
}