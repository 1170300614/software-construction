/* Copyright (c) 2015-2016 MIT 6.005 course staff, all rights reserved.
 * Redistribution of original or derived work requires permission of course staff.
 */
package P1.test.poet;

import P1.src.poet.GraphPoet;
import org.junit.Test;

import java.io.File;
import java.io.IOException;
import java.util.Collections;
import java.util.List;

import static org.junit.Assert.*;

/**
 * Tests for GraphPoet.
 */
public class GraphPoetTest{

    // Testing strategy
    //   TODO

    @Test(expected = AssertionError.class)
    public void testAssertionsEnabled(){
        assert false; // make sure assertions are enabled with VM argument: -ea
    }

    // TODO tests

    private static final GraphPoet instantiateGraph(String source){
        try{
            final File corpus = new File(source);
            GraphPoet graphPoet = new GraphPoet(corpus);
            return graphPoet;
        }
        catch(IOException e){
            throw new RuntimeException(e.getMessage());
        }
    }

    final GraphPoet oneWord = instantiateGraph("src/P1/test/poet/TestOneWord.txt");
    final GraphPoet oneLine = instantiateGraph("src/P1/test/poet/TestOneLine.txt");
    final GraphPoet multipleLines = instantiateGraph("src/P1/test/poet/TestMultipleLines.txt");

    // Tests for GraphPoet()
    @Test
    public void testGraphPoet_OneWord(){
        List<String> corpusWords = oneWord.getCorpusWords();

        assertEquals("Expected corpus contains one word", 1, corpusWords.size());
        assertTrue("Expected word in lowercase", corpusWords.contains("test"));
    }

    @Test
    public void testGraphPoet_OneLine(){
        List<String> corpusWords = oneLine.getCorpusWords();

        assertEquals("Expected all of the words in the corpus", 8, corpusWords.size());
        assertTrue("Expected words in lowercase", corpusWords.contains("poet."));
    }

    @Test
    public void testGraphPoet_MultipleLine(){
        List<String> corpusWords = multipleLines.getCorpusWords();

        assertNotSame("Expected non-empty list", Collections.EMPTY_LIST, corpusWords);
        assertTrue("Expected words in lowercase", corpusWords.contains("and"));
    }

    // Tests for poem()
    @Test
    public void testPoem_OneWord(){
        String input = "input";
        String output = oneWord.poem(input);

        assertEquals("Expected output as unchanged input", input, output);
    }

    @Test
    public void testPoem_MultipleWords(){
        String input = "And this is test for one line POET.";
        String output = oneLine.poem(input);
        String expected = "And this is a test for one line POET.";

        assertEquals("Expected poetic output with words in input unchanged", expected, output);
    }

    @Test
    public void testPoem_MultipleAdjacencies(){
        String input = "I REJECT OPINION";
        String output = multipleLines.poem(input);

        assertNotSame("Expected a bridge word inserted", input, output);
        assertTrue("Expected input words unchanged", output.contains("I") && output.contains("REJECT"));
        assertTrue("Expected correct bridge word",
                output.contains("I") || output.contains("REJECT") || output.contains("your") || output.contains(
                        "OPINION"));
    }
}