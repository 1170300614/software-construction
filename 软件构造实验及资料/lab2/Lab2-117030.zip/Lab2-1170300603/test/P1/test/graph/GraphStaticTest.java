/* Copyright (c) 2015-2016 MIT 6.005 course staff, all rights reserved.
 * Redistribution of original or derived work requires permission of course staff.
 */
package P1.test.graph;

import P1.src.graph.Graph;
import org.junit.Test;

import java.util.Collections;

import static org.junit.Assert.assertEquals;
import static org.junit.Assert.assertTrue;

/**
 * Tests for static methods of Graph.
 * <p>
 * To facilitate testing multiple implementations of Graph, instance methods are
 * tested in GraphInstanceTest.
 */
public class GraphStaticTest{

    // Testing strategy
    //   empty()
    //     no inputs, only output is empty graph
    //     observe with vertices()

    @Test(expected = AssertionError.class)
    public void testAssertionsEnabled(){
        assert false; // make sure assertions are enabled with VM argument: -ea
    }

    @Test
    public void testEmptyVerticesEmpty(){
        assertEquals("expected empty() graph to have no vertices", Collections.emptySet(), Graph.empty().vertices());
    }

    // TODO test other vertex label types in Problem 3.2
    @Test
    public void testStringAsLabel(){
        Graph<String> graph = Graph.empty();
        String vertex1 = "vertex1";
        String vertex2 = "vertex2";
        String vertex3 = "vertex3";
        int weight1 = 2;
        int weight2 = 1;

        boolean addedVertex1 = graph.add(vertex1);
        boolean addedVertex2 = graph.add(vertex2);

        int previousWeight1 = graph.set(vertex1, vertex2, weight1);
        int previousWeight2 = graph.set(vertex3, vertex1, weight2);
        int initialVerticesSize = graph.vertices().size();
        boolean removedVertex2 = graph.remove(vertex1);

        assertTrue("Expected vertex1 has been added", addedVertex1);
        assertTrue("Expected vertex2 has been added", addedVertex2);
        assertEquals("Expected no previous weight", 0, previousWeight1);
        assertEquals("Expected no previous weight", 0, previousWeight2);

        assertEquals("Expected correct num vertices", 3, initialVerticesSize);
        assertTrue("Expected vertex2 removed", removedVertex2);
        assertEquals("Expected one vertex removed", initialVerticesSize - 1, graph.vertices().size());
        System.out.println(graph);
    }

    @Test
    public void testIntegerAsLabel(){
        Graph<Integer> graph = Graph.empty();
        int vertex1 = 1;
        int vertex2 = 2;
        int vertex3 = 3;
        int weight1 = 2;
        int weight2 = 1;

        boolean addedVertex1 = graph.add(vertex1);
        boolean addedVertex2 = graph.add(vertex2);

        int previousWeight1 = graph.set(vertex1, vertex2, weight1);
        int previousWeight2 = graph.set(vertex3, vertex1, weight2);
        int initialVerticesSize = graph.vertices().size();
        boolean removedVertex2 = graph.remove(vertex3);

        assertTrue("Expected vertex1 added", addedVertex1);
        assertTrue("Expected vertex2 added", addedVertex2);
        assertEquals("Expected no previous weight", 0, previousWeight1);
        assertEquals("Expected no previous weight", 0, previousWeight2);

        assertEquals("Expected correct num vertices", 3, initialVerticesSize);
        assertTrue("Expected vertex2 removed", removedVertex2);
        assertEquals("Expected one vertex removed", initialVerticesSize - 1, graph.vertices().size());
        System.out.println(graph);
    }
}