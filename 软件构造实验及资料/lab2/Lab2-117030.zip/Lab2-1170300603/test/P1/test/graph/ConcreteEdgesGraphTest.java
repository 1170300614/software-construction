/* Copyright (c) 2015-2016 MIT 6.005 course staff, all rights reserved.
 * Redistribution of original or derived work requires permission of course staff.
 */
package P1.test.graph;

import P1.src.graph.ConcreteEdgesGraph;
import P1.src.graph.Graph;
import org.junit.Test;

import java.util.Collections;
import java.util.stream.Collectors;

import static org.junit.Assert.assertEquals;
import static org.junit.Assert.assertTrue;

/**
 * Tests for ConcreteEdgesGraph.
 * <p>
 * This class runs the GraphInstanceTest tests against ConcreteEdgesGraph, as
 * well as tests for that particular implementation.
 * <p>
 * Tests against the Graph spec should be in GraphInstanceTest.
 */
public class ConcreteEdgesGraphTest extends GraphInstanceTest{

    /*
     * Provide a ConcreteEdgesGraph for tests in GraphInstanceTest.
     */
    @Override
    public Graph<String> emptyInstance(){
        return new ConcreteEdgesGraph();
    }

    /*
     * Testing ConcreteEdgesGraph...
     */

    // Testing strategy for ConcreteEdgesGraph.toString()
    //   TODO

    // TODO tests for ConcreteEdgesGraph.toString()
    @Test
    public void testConcreteEdgesGraphToString(){
        Graph<String> graph = new ConcreteEdgesGraph<>();
        assertEquals("The empty graph should return a information", "Empty graph", graph.toString());
    }

    @Test
    public void testSet(){
        Graph<String> graph = new ConcreteEdgesGraph<>();
        graph.set("source1", "target1", 1);
        graph.set("source2", "target2", 1);

        assertEquals("The graph should include the test edge", graph.toString(),
                "source1 -> target1: 1->source2 -> target2: 1");
    }

    @Test
    public void testToStringMultiple(){
        Graph<String> graph = new ConcreteEdgesGraph<>();
        graph.set("source1", "target1", 1);
        graph.set("source1", "target2", 1);
        graph.set("source3", "target3", 1);

        assertEquals("The graph should include the test edge", graph.toString(),
                "source1 -> target1: 1->source1 -> target2: 1->source3 -> target3: 1");
        graph.remove("source1");
        assertEquals("The graph should include the test edge",graph.toString(),"source3 -> target3: 1");
    }
}