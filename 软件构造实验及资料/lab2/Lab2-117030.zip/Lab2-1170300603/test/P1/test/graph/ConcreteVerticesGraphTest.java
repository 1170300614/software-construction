/* Copyright (c) 2015-2016 MIT 6.005 course staff, all rights reserved.
 * Redistribution of original or derived work requires permission of course staff.
 */
package P1.test.graph;

import P1.src.graph.ConcreteVerticesGraph;
import P1.src.graph.Graph;
import org.junit.Test;

import static org.junit.Assert.assertEquals;

/**
 * Tests for ConcreteVerticesGraph.
 * <p>
 * This class runs the GraphInstanceTest tests against ConcreteVerticesGraph, as
 * well as tests for that particular implementation.
 * <p>
 * Tests against the Graph spec should be in GraphInstanceTest.
 */
public class ConcreteVerticesGraphTest extends GraphInstanceTest{

    /*
     * Provide a ConcreteVerticesGraph for tests in GraphInstanceTest.
     */
    @Override
    public Graph<String> emptyInstance(){
        return new ConcreteVerticesGraph();
    }

    /*
     * Testing ConcreteVerticesGraph...
     */

    // Testing strategy for ConcreteVerticesGraph.toString()
    //   TODO

    // TODO tests for ConcreteVerticesGraph.toString()

    /*
     * Testing Vertex...
     */

    // Testing strategy for Vertex
    //   TODO

    // TODO tests for operations of Vertex
    @Test
    public void testConcreteEdgesGraphToString(){
        Graph<String> graph = new ConcreteVerticesGraph<>();
        assertEquals("The empty graph should return a information", "Empty graph", graph.toString());
    }

    @Test
    public void testSet(){
        Graph<String> graph = new ConcreteVerticesGraph<>();
        graph.set("source1", "target1", 1);
        graph.set("source2", "target2", 1);

        assertEquals("The graph should include the test edge", graph.toString(),
                "source1 -> {target1=1} source2 -> {target2=1}");
    }

    @Test
    public void testToStringMultiple(){
        Graph<String> graph = new ConcreteVerticesGraph<>();
        graph.set("source1", "target1", 1);
        graph.set("source1", "target2", 1);
        graph.set("target2", "target3", 1);

        assertEquals("The graph should include the test edge", graph.toString(),
                "source1 -> {target2=1, target1=1} target2 -> {target3=1}");
        graph.remove("target3");
        assertEquals("The graph should include the test edge", graph.toString(),
                "source1 -> {target2=1, target1=1}");
    }
}