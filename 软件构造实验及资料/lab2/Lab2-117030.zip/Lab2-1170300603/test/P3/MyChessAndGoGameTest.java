package P3;
import org.junit.Test;

import static junit.framework.Assert.assertFalse;
import static junit.framework.Assert.assertTrue;
public class MyChessAndGoGameTest{

    private final Player player1 = new Player("Billy");
    private final Player player2 = new Player("Van");
    private final Board chessBoard = new Board(8, "CHESS BOARD", "grid");
    private final Board goBoard = new Board(19, "GO BOARD", "cross");
    private final Game chessGame = new Game("CHESS GAME", "chess");
    private final Game goGame = new Game("GO GAME", "go");
    private final Piece[] chesses = chessBoard.generatePieces(player1, player2);
    private final Piece[] goChesses = goBoard.generatePieces(player1, player2);

    @Test
    public void hasChessTest(){
        assertTrue("The chess can be used", player1.hasChess(chesses, player1, "king", 1));
        assertFalse("The chess can not be used", player1.hasChess(chesses, player1, "king", 2));
        assertTrue("The chess can be used", player1.hasChess(chesses, player2, "pawn", 8));
        assertFalse("The chess can not be used", player1.hasChess(chesses, player2, "pawn", 9));
    }

    @Test
    public void moveChessTest(){
        Piece chess_1 = player1.selectChess(chesses, player1, "king", 1);
        Piece chess_2 = player2.selectChess(chesses, player2, "pawn", 8);

        assertTrue("The chess can be moved", player1.moveChess(chessBoard, chesses, chess_1, 4, 4));
        assertFalse("The chess can not be moved to own chess", player1.moveChess(chessBoard, chesses, chess_1, 1, 1));
        assertTrue("The chess can be moved to attack", player2.moveChess(chessBoard, chesses, chess_2, 2, 2));
        assertFalse("The chess can not be moved to out of chessBoard",
                player2.moveChess(chessBoard, chesses, chess_2, -34, -2));
    }

    @Test
    public void isGameOverTest(){
        Piece[] chesses = chessBoard.generatePieces(player1, player2);
        assertFalse("Not end", chessBoard.isGameOver(chessGame, chesses));
        Piece chess_1 = player1.selectChess(chesses, player1, "king", 1);

        player1.moveChess(chessBoard, chesses, chess_1, 0, 6);
        player1.moveChess(chessBoard, chesses, chess_1, 1, 6);
        player1.moveChess(chessBoard, chesses, chess_1, 2, 6);
        player1.moveChess(chessBoard, chesses, chess_1, 3, 6);
        player1.moveChess(chessBoard, chesses, chess_1, 4, 6);
        player1.moveChess(chessBoard, chesses, chess_1, 5, 6);
        player1.moveChess(chessBoard, chesses, chess_1, 6, 6);
        player1.moveChess(chessBoard, chesses, chess_1, 7, 6);
        player1.moveChess(chessBoard, chesses, chess_1, 0, 7);
        player1.moveChess(chessBoard, chesses, chess_1, 1, 7);
        player1.moveChess(chessBoard, chesses, chess_1, 2, 7);
        player1.moveChess(chessBoard, chesses, chess_1, 3, 7);
        player1.moveChess(chessBoard, chesses, chess_1, 4, 7);
        player1.moveChess(chessBoard, chesses, chess_1, 5, 7);
        player1.moveChess(chessBoard, chesses, chess_1, 6, 7);
        player1.moveChess(chessBoard, chesses, chess_1, 7, 7);
        assertTrue("Game Over and player2(Van) losed", chessBoard.isGameOver(chessGame, chesses));
    }

    @Test
    public void hasGoTest(){
        assertTrue("The chess can be used", player1.hasGo(goChesses, player1));
        assertTrue("The chess can be used", player2.hasGo(goChesses, player2));
    }

    @Test
    public void moveGoTest(){
        Piece go_1 = player1.selectGo(goChesses, player1);
        Piece go_2 = player2.selectGo(goChesses, player2);
        Piece go_3 = player1.selectGo(goChesses, player1);

        assertTrue("The chess can be moved", player1.moveGo(goBoard, goChesses, go_1, 10, 10));
        assertFalse("The chess can not be moved to locations that have chesses", player2.moveGo(goBoard, goChesses, go_2, 10, 10));
        assertFalse("The chess can not be moved to out of chessBoard",
                player2.moveChess(goBoard, goChesses, go_3, -34, -2));
    }
}