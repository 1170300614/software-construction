package P2;

import org.junit.Test;
import static org.junit.Assert.*;

public class FriendshipGraphTest{

    @Test
    public void test(){
        FriendshipGraph graph = new FriendshipGraph();

        Person honoka = new Person("Kosaka Honoka");
        Person eli = new Person("Eli Ayase");
        Person kotori = new Person("Kotori Minami");
        Person umi = new Person("Umi Sonoda");
        Person rin = new Person("Rin Hoshizora");
        Person maki = new Person("Maki Nishikino");
        Person nozomi = new Person("Nozomi Tojo");
        Person hanayo = new Person("Hanayo Koizumi");
        Person nico = new Person("Nico Yazawa");

        graph.addVertex(honoka);
        graph.addVertex(eli);
        graph.addVertex(kotori);
        graph.addVertex(umi);
        graph.addVertex(rin);
        graph.addVertex(maki);
        graph.addVertex(nozomi);
        graph.addVertex(hanayo);
        graph.addVertex(nico);

        graph.addEdge(honoka, kotori);
        graph.addEdge(kotori, honoka);
        graph.addEdge(honoka, umi);
        graph.addEdge(umi, honoka);
        graph.addEdge(umi, kotori);
        graph.addEdge(kotori, umi);
        graph.addEdge(honoka, hanayo);
        graph.addEdge(hanayo, rin);
        graph.addEdge(hanayo, maki);
        graph.addEdge(rin, maki);
        graph.addEdge(honoka, eli);
        graph.addEdge(eli, nozomi);
        graph.addEdge(eli, umi);
        graph.addEdge(umi, eli);
        graph.addEdge(nozomi, eli);
        graph.addEdge(nico, maki);
        graph.addEdge(maki, nico);

        assertEquals("Expected Distance", 1, graph.getDistance(honoka, kotori));
        assertEquals("Expected Distance", 0, graph.getDistance(honoka, honoka));
        assertEquals("Expected Distance", 2, graph.getDistance(honoka, maki));
        assertEquals("Expected Distance", -1, graph.getDistance(nico, hanayo));
        assertEquals("Expected Distance", 2, graph.getDistance(nozomi, umi));
        assertEquals("Expected Distance", 6, graph.getDistance(nozomi, nico));
    }
}