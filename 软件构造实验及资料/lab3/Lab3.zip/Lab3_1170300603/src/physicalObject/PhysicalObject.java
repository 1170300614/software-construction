package physicalObject;

import circularOrbit.CircularOrbit;
/**
 * The interface of physical object
 */
public interface PhysicalObject {
	/**
	 * Get the label of the physical object
	 *
	 * @return the label
	 */
	String getLabel();
	
	/**
	 * get the initial azimuth of a physical object
	 *
	 * @return the initial azimuth
	 */
	double getAzimuth();
	
	/**
	 * Override equals
	 *
	 * @param physicalObject another physical object
	 * @return if equals
	 */
	boolean equals(PhysicalObject physicalObject);
	
	/**
	 * Override hashCode
	 *
	 * @return hash code
	 */
	int hashCode();
}