package physicalObject;

import circularOrbit.CircularOrbit;
import track.Track;

import java.util.Random;

public class Electronic implements PhysicalObject {
	private final String rank;
	private final double initialAzimuth;
	
	public String getLabel() { return rank; }
	
	public double getAzimuth() { return initialAzimuth; }
	
	private void checkRep() {
		assert this.rank != null;
		assert initialAzimuth >= 0 && initialAzimuth < 360;
	}
	
	public Electronic() {
		this.rank = "default";
		this.initialAzimuth = 0;
		checkRep();
	}
	
	public Electronic(String rank, double initialAzimuth) {
		this.rank = rank;
		this.initialAzimuth = initialAzimuth;
		checkRep();
	}
	
	@Override public boolean equals(PhysicalObject that) {
		if (!(that instanceof Electronic))
			return false;
		Electronic thatElectronic = (Electronic) that;
		return this.getLabel().equals(thatElectronic.getLabel()) &&
				this.getAzimuth() == thatElectronic.getAzimuth();
	}
	
	@Override public int hashCode() { return rank.hashCode(); }
}