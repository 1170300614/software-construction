package physicalObject;

import circularOrbit.CircularOrbit;
import track.Track;

public class Planet implements PhysicalObject {
	private final String label;
	private final String form;
	private final String color;
	private final double planetRadius;
	private final double orbitRadius;
	private final double revolutionSpeed;
	private final String orientation;
	private final double initialAzimuth;
	
	public String getLabel() { return label; }
	
	public String getForm() { return form; }
	
	public String getColor() { return color; }
	
	public double getPlanetRadius() { return planetRadius; }
	
	public double getOrbitRadius() { return orbitRadius; }
	
	public double getRevolutionSpeed() { return revolutionSpeed; }
	
	public String getOrientation() { return orientation; }
	
	public double getAzimuth() {return initialAzimuth;}
	
	private void checkRep() {
		assert this.label != null;
		assert this.form != null;
		assert this.color != null;
		assert this.planetRadius >= 0;
		assert this.orbitRadius >= this.planetRadius;
		assert this.revolutionSpeed >= 0;
		assert this.orientation != null;
		assert initialAzimuth >= 0 && initialAzimuth <= 360;
	}
	
	public Planet() {
		this.label = "default";
		this.form = "default";
		this.color = "default";
		this.planetRadius = 0;
		this.orbitRadius = 0;
		this.revolutionSpeed = 0;
		this.orientation = "default";
		this.initialAzimuth = 0;
		checkRep();
	}
	
	public Planet(String name, String form, String color, double planetRadius, double orbitRadius,
	              double revolutionSpeed, String orientation, double initialAngle) {
		this.label = name;
		this.form = form;
		this.color = color;
		this.planetRadius = planetRadius;
		this.orbitRadius = orbitRadius;
		this.revolutionSpeed = revolutionSpeed;
		this.orientation = orientation;
		this.initialAzimuth = initialAngle;
		checkRep();
	}
	
	public boolean equals(PhysicalObject that) {
		if (!(that instanceof Planet))
			return false;
		Planet thatPlanet = (Planet) that;
		return this.getLabel().equals(thatPlanet.getLabel()) &&
				this.getAzimuth() == thatPlanet.getAzimuth();
	}
	
	@Override public int hashCode() {
		return label.hashCode() ^ form.hashCode() ^ color.hashCode() ^ (int) planetRadius ^
				(int) orbitRadius ^ (int) revolutionSpeed ^ orientation.hashCode();
	}
}