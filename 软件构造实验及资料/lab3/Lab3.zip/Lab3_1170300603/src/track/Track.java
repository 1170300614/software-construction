package track;

/**
 * Immutable type
 * Track
 */
public class Track {
	private final String label;
	private final double radius;
	
	public Track(String label) {
		this.label = label;
		this.radius = 0;
		checkRep();
	}
	
	public Track(String label, double radius) {
		this.label = label;
		this.radius = radius;
		checkRep();
	}
	
	private void checkRep() { assert this.radius >= 0; }
	
	public String getLabel() { return label; }
	
	public double getRadius() { return radius; }
	
	public boolean equals(Track that) {
		if (!(that instanceof Track))
			return false;
		Track thatTrack = (Track) that;
		return this.getLabel().equals(thatTrack.getLabel()) &&
				this.getRadius() == thatTrack.getRadius();
	}
	
	@Override public int hashCode() { return label.hashCode() ^ (int) radius; }
}