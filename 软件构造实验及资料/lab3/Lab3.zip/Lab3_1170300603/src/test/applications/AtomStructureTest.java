package test.applications;

import applications.AtomStructure;

import org.junit.Test;
import static org.junit.Assert.assertEquals;

/**
 * AtomStructure Tester.
 *
 * @author <1170300603>
 * @version 1.0
 * @since <pre>4月 20, 2019</pre>
 */
public class AtomStructureTest {
	/**
	 * Method: buildAtomStructureFromFile(String fileName)
	 */
	@Test public void testBuildTracksFromFile() throws Exception {
		AtomStructure atomStructure =
				new AtomStructure().buildAtomStructureFromFile("test/AtomicStructure_Medium.txt");
		assertEquals("the core's name should be \"Rb\"", "Er",
		             atomStructure.getCentralObject().getLabel());
		assertEquals("the number of track should be 6", 6, atomStructure.getTracks().size());
		assertEquals("the number of electronic should be 68", 68,
		             atomStructure.getPhysicalObjects().size());
	}
	
	/**
	 * Method: transit(Electronic electronic, Track target)
	 */
	@Test public void testTransit() throws Exception{
		AtomStructure atomStructure =
				new AtomStructure().buildAtomStructureFromFile("test/AtomicStructure_Medium.txt");
		//assertEquals("the electronic_1 is on track_1",);
	}
}