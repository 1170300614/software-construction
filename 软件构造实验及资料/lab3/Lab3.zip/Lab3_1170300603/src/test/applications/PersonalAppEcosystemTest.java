package test.applications;

import applications.PersonalAppEcosystem;
import org.junit.Test;

import java.text.SimpleDateFormat;
import java.util.Date;
import java.util.List;

import static org.junit.Assert.assertEquals;

/**
 * PersonalAppEcosystem Tester.
 *
 * @author <1170300603>
 * @version 1.0
 * @since <pre>4月 20, 2019</pre>
 */
public class PersonalAppEcosystemTest {
	/**
	 * Method: buildPersonalAppEcosystemFromFile(String fileName)
	 */
	@Test public void testBuildTracksFromFile() throws Exception {
		PersonalAppEcosystem personalAppEcosystem =
				new PersonalAppEcosystem().buildPersonalAppEcosystemFromFile(
						"test/PersonalAppEcosystem_Larger.txt");
		assertEquals("the user's name should be \"TimWong\"", "TimWong",
		             personalAppEcosystem.getCentralObject().getLabel());
		assertEquals("the number of track should be 10", 10,
		             personalAppEcosystem.getTracks().size());
		assertEquals("the number of app should be 400", 400,
		             personalAppEcosystem.getPhysicalObjects().size());
		assertEquals("the number of installLog should be 400", 400,
		             personalAppEcosystem.getPhysicalObjects().size());
		assertEquals("the number of usageLog should be 400", 400,
		             personalAppEcosystem.getPhysicalObjects().size());
		assertEquals("the number of uninstallLog should be 400", 400,
		             personalAppEcosystem.getPhysicalObjects().size());
	}
	
	/**
	 * Method: getIntervalTimeList()
	 */
	@Test public void testGetIntervalTimeList() throws Exception {
		PersonalAppEcosystem personalAppEcosystem =
				new PersonalAppEcosystem().buildPersonalAppEcosystemFromFile(
						"test/PersonalAppEcosystem_Medium.txt");
		List<Date> dateList = personalAppEcosystem.getIntervalTimeList();
		SimpleDateFormat simpleDateFormat = new SimpleDateFormat("yyyy-MM-dd hh:mm:ss");
		Date begin = simpleDateFormat.parse("2019-01-01 08:16:11");
		Date end = simpleDateFormat.parse("2019-05-30 22:53:01");
		assertEquals("size should be 151 day", 151, dateList.size());
		assertEquals("earliest time should be 2019-01-01 08:16:11", begin, dateList.get(0));
		assertEquals("latest time should be 2019-05-30 22:53:51", end,
		             dateList.get((dateList.size() - 1)));
	}
}