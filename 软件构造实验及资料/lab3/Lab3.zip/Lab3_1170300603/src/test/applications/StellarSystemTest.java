package test.applications;

import applications.StellarSystem;
import org.junit.Test;
import physicalObject.Planet;
import track.Track;

import static org.junit.Assert.assertEquals;

/**
 * StellarSystem Tester.
 *
 * @author <1170300603>
 * @version 1.0
 * @since <pre>4月 20, 2019</pre>
 */
public class StellarSystemTest {
	/**
	 * Method: buildStellarSystemFromFile(String fileName)
	 */
	@Test public void testBuildTracksFromFile() throws Exception {
		StellarSystem stellarSystem =
				new StellarSystem().buildStellarSystemFromFile("test/StellarSystem_Larger.txt");
		assertEquals("the stellar's name should be \"ThreeBody\"", "ThreeBody",
		             stellarSystem.getCentralObject().getLabel());
		assertEquals("the number of track should be 10000", 10000,
		             stellarSystem.getTracks().size());
		assertEquals("the number of planet should be 10000", 10000,
		             stellarSystem.getPhysicalObjects().size());
	}
	
	/**
	 * Method: move(Planet planet, double time)
	 */
	@Test public void testMove() {
		StellarSystem stellarSystem = new StellarSystem();
		Track track_1 = new Track("track1", 1);
		Track track_2 = new Track("track2", 1);
		stellarSystem.addTrack(track_1);
		stellarSystem.addTrack(track_2);
		Planet planet_1 = new Planet("Earth1", "solid", "blue", 6731, 1.496e8, 30, "CW", 22.3);
		Planet planet_2 = new Planet("Earth2", "solid", "blue", 6731, 1.496e8, 30, "CCW", 22.3);
		stellarSystem.addObject(track_1, planet_1);
		stellarSystem.addObject(track_2, planet_2);
		assertEquals("expected azimuth should be ", 35.893,
		             stellarSystem.move(planet_1, 392856.4531), 0.1);
		assertEquals("expected azimuth should be ", 8.707,
		             stellarSystem.move(planet_2, 392856.4531), 0.1);
	}
}