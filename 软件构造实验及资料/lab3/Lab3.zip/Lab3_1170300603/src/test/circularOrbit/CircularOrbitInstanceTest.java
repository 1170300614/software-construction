package test.circularOrbit;

import centralObject.CentralObject;
import circularOrbit.CircularOrbit;
import org.junit.Test;
import physicalObject.PhysicalObject;

import java.util.Collections;

import static org.junit.Assert.assertEquals;

/**
 * ConcreteCircularOrbit Tester.
 *
 * @author <1170300603>
 * @version 1.0
 * @since <pre>April 9, 2019</pre>
 */
public abstract class CircularOrbitInstanceTest {
	public abstract CircularOrbit<CentralObject, PhysicalObject> emptyInstance();
	
	@Test(expected = AssertionError.class) public void testAssertionsEnabled() {
		assert false; // make sure assertions are enabled with VM argument: -ea
	}
	
	@Test public void testInitialTracksEmpty() {
		assertEquals("expected new circular orbit to have no tracks and orbit objects",
		             Collections.EMPTY_LIST, emptyInstance().getTracks());
	}
	
	@Test public void testInitialCentralObjectEmpty() {
		assertEquals("excepted new circular orbit to have no central object", null,
		             emptyInstance().getCentralObject());
	}
	
	@Test public void testInitialPhysicalObjectsEmpty() {
		assertEquals("excepted new circular orbit to have no physical object",
		             Collections.EMPTY_SET, emptyInstance().getPhysicalObjects());
	}
}