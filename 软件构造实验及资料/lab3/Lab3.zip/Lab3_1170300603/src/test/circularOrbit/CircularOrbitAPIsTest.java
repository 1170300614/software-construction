package test.circularOrbit;

import applications.AtomStructure;
import applications.PersonalAppEcosystem;
import applications.StellarSystem;
import centralObject.CentralObject;
import circularOrbit.CircularOrbit;
import circularOrbit.CircularOrbitAPIs;
import circularOrbit.ConcreteCircularOrbit;
import circularOrbit.Difference;
import org.junit.Test;
import physicalObject.PhysicalObject;
import physicalObject.Planet;
import track.Track;

import static org.junit.Assert.assertEquals;

/**
 * CircularOrbitAPIs Tester.
 *
 * @author <1170300603>
 * @version 1.0
 * @since <pre>4月 12, 2019</pre>
 */
public class CircularOrbitAPIsTest extends CircularOrbitInstanceTest {
	private final CircularOrbitAPIs circularOrbitAPIs = new CircularOrbitAPIs();
	
	@Override public CircularOrbit<CentralObject, PhysicalObject> emptyInstance() {
		return new ConcreteCircularOrbit<>();
	}
	
	/**
	 * Method: getObjectDistributionEntropy(CircularOrbit c)
	 */
	@Test public void testGetObjectDistributionEntropy() throws Exception {
		StellarSystem stellarSystem =
				new StellarSystem().buildStellarSystemFromFile("test/StellarSystem_Larger.txt");
		assertEquals("the entropy of system should be 82108.928", 82108.9,
		             circularOrbitAPIs.getObjectDistributionEntropy(stellarSystem), 0.1);
		AtomStructure atomStructure =
				new AtomStructure().buildAtomStructureFromFile("test/AtomicStructure_Medium.txt");
		assertEquals("the entropy of system should be 88.307", 88.3,
		             circularOrbitAPIs.getObjectDistributionEntropy(atomStructure), 0.1);
		PersonalAppEcosystem personalAppEcosystem =
				new PersonalAppEcosystem().buildPersonalAppEcosystemFromFile(
						"test/PersonalAppEcosystem_Larger.txt");
		assertEquals("the entropy of system should be 88.307", 897.3,
		             circularOrbitAPIs.getObjectDistributionEntropy(personalAppEcosystem), 0.1);
	}
	
	/**
	 * Method: getLogicalDistance(CircularOrbit c, E e1, E e2)
	 */
	@Test public void testGetLogicalDistance() {
		CircularOrbit<CentralObject, PhysicalObject> circularOrbitInstance = emptyInstance();
		Track track_1 = new Track("track_1", 1);
		Track track_2 = new Track("track_2", 2);
		Track track_3 = new Track("track_3", 3);
		Track track_4 = new Track("track_4", 4);
		circularOrbitInstance.addTrack(track_1);
		circularOrbitInstance.addTrack(track_2);
		circularOrbitInstance.addTrack(track_3);
		circularOrbitInstance.addTrack(track_4);
		Planet object_1 = new Planet();
		Planet object_2 = new Planet("Earth_1", "solid", "blue", 1.27e4, 1.5e9, 30, "CW", 73.54);
		Planet object_3 = new Planet("Earth_2", "solid", "blue", 1.27e4, 1.5e9, 30, "CW", 271.3);
		Planet object_4 = new Planet("Earth_3", "solid", "blue", 1.27e4, 1.5e9, 30, "CW", 1.98);
		circularOrbitInstance.addObject(track_1, object_1);
		circularOrbitInstance.addObject(track_2, object_2);
		circularOrbitInstance.addObject(track_3, object_3);
		circularOrbitInstance.addObject(track_4, object_4);
		circularOrbitInstance.addRelationOfPhysicalObject(object_1, object_2);
		circularOrbitInstance.addRelationOfPhysicalObject(object_2, object_3);
		circularOrbitInstance.addRelationOfPhysicalObject(object_2, object_4);
		circularOrbitInstance.addRelationOfPhysicalObject(object_3, object_4);
		assertEquals("object_1 to object_1 logical distance should be 2", 0,
		             circularOrbitAPIs.getLogicalDistance(circularOrbitInstance, object_1,
		                                                  object_1));
		assertEquals("object_1 to object_4 logical distance should be 2", 2,
		             circularOrbitAPIs.getLogicalDistance(circularOrbitInstance, object_1,
		                                                  object_4));
		assertEquals("object_4 to object_1 logical distance should be 2", 2,
		             circularOrbitAPIs.getLogicalDistance(circularOrbitInstance, object_4,
		                                                  object_1));
	}
	
	/**
	 * Method: getPhysicalDistance(CircularOrbit c, E e1, E e2)
	 */
	@Test public void testGetPhysicalDistance() {
		CircularOrbit<CentralObject, PhysicalObject> circularOrbitInstance = emptyInstance();
		Track track_1 = new Track("track_1", 1.496e8);
		Track track_2 = new Track("track_2", 2.279e8);
		Track track_3 = new Track("track_3", 7.783e8);
		circularOrbitInstance.addTrack(track_1);
		circularOrbitInstance.addTrack(track_2);
		circularOrbitInstance.addTrack(track_3);
		Planet object_1 =
				new Planet("Earth", "Solid", "Blue", 6378.137, 1.496e8, 29.783, "CW", 180);
		Planet object_2 =
				new Planet("Mars", "Solid", "Red", 637.137, 2.279e8, 1000.93, "CCW", 308.7);
		Planet object_3 = new Planet("Jupiter", "Gas", "Blue", 1637.007, 7.783e8, 30, "CW", 115.7);
		circularOrbitInstance.addObject(track_1, object_1);
		circularOrbitInstance.addObject(track_2, object_2);
		circularOrbitInstance.addObject(track_3, object_3);
		assertEquals("object_1 to object_2 's physical distance should be 3.421e8", 3.421e8,
		             circularOrbitAPIs.getPhysicalDistance(circularOrbitInstance, object_1,
		                                                   object_2), 1e6);
		assertEquals("object_1 to object_3 's physical distance should be 7.260e8", 7.260e8,
		             circularOrbitAPIs.getPhysicalDistance(circularOrbitInstance, object_1,
		                                                   object_3), 1e6);
		assertEquals("object_2 to object_3 's physical distance should be 5.586e8", 5.586e8,
		             circularOrbitAPIs.getPhysicalDistance(circularOrbitInstance, object_2,
		                                                   object_3), 1e6);
	}
	
	/**
	 * Method: getDifference(CircularOrbit c1, CircularOrbit c2)
	 */
	@Test public void testGetDifference() throws Exception {
		PersonalAppEcosystem personalAppEcosystem1 =
				new PersonalAppEcosystem().buildPersonalAppEcosystemFromFile(
						"test" + "/PersonalAppEcosystem_Medium.txt");
		PersonalAppEcosystem personalAppEcosystem2 =
				new PersonalAppEcosystem().buildPersonalAppEcosystemFromFile(
						"test" + "/PersonalAppEcosystem_Medium2.txt");
		Difference difference =
				circularOrbitAPIs.getDifference(personalAppEcosystem1, personalAppEcosystem2);
		assertEquals("the difference of track size should be 0", 0,
		             difference.getTrackSizeDifference());
		assertEquals("the difference of track10's object size should be 5", 5,
		             difference.getPositiveObjectDifference().get(10).size() -
				             difference.getNegativeObjectDifference().get(10).size());
	}
}