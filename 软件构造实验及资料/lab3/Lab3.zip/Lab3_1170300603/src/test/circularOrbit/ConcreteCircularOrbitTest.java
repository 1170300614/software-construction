package test.circularOrbit;

import centralObject.CentralObject;
import centralObject.Stellar;
import circularOrbit.CircularOrbit;
import circularOrbit.ConcreteCircularOrbit;
import physicalObject.PhysicalObject;
import physicalObject.Planet;
import track.Track;
import java.util.Collections;
import org.junit.Test;
import static junit.framework.Assert.assertEquals;
import static org.junit.Assert.assertFalse;
import static org.junit.Assert.assertTrue;

/**
 * ConcreteCircularOrbit Tester.
 *
 * @author <1170300603>
 * @version 1.0
 * @since <pre>April 9, 2019</pre>
 */
public class ConcreteCircularOrbitTest extends CircularOrbitInstanceTest {
	//Use Stellar as central object and Planet as the physical object
	@Override public CircularOrbit<CentralObject, PhysicalObject> emptyInstance() {
		return new ConcreteCircularOrbit<>();
	}
	
	/**
	 * Method: setCentralObject(L centralObject)
	 */
	@Test public void testSetCentralObject() {
		CircularOrbit<CentralObject, PhysicalObject> circularOrbitInstance = emptyInstance();
		Stellar central = new Stellar();
		circularOrbitInstance.setCentralObject(central);
		assertEquals("Central object's label should be \"default\"", "default",
		             circularOrbitInstance.getCentralObject().getLabel());
		Stellar newCentral = new Stellar("Sun", 0, 0);
		circularOrbitInstance.setCentralObject(newCentral);
		assertEquals("Central object's label should be \"Sun\"", "Sun",
		             circularOrbitInstance.getCentralObject().getLabel());
	}
	
	/**
	 * Method: addTrack(Track track)
	 */
	@Test public void testAddTrack() {
		CircularOrbit<CentralObject, PhysicalObject> circularOrbitInstance = emptyInstance();
		assertEquals("No track", Collections.EMPTY_LIST, circularOrbitInstance.getTracks());
		Track track_1 = new Track("track", 1);
		circularOrbitInstance.addTrack(track_1);
		assertEquals("There is one track", 1, circularOrbitInstance.getTracks().size());
		assertEquals("The size of orbit objects should be 0", 0,
		             circularOrbitInstance.getPhysicalObjects().size());
		Track track_2 = new Track("track", 2);
		circularOrbitInstance.addTrack(track_2);
		assertEquals("There is 2 tracks", 2, circularOrbitInstance.getTracks().size());
	}
	
	/**
	 * Method: removeTrack()(Track track)
	 */
	@Test public void testReduceTrack() {
		CircularOrbit<CentralObject, PhysicalObject> circularOrbitInstance = emptyInstance();
		Track track_1 = new Track("track", 1);
		circularOrbitInstance.addTrack(track_1);
		assertEquals("There is one track", 1, circularOrbitInstance.getTracks().size());
		Track track_2 = new Track("track", 1);
		circularOrbitInstance.removeTrack(track_2);
		assertEquals("No track", Collections.EMPTY_LIST, circularOrbitInstance.getTracks());
	}
	
	/**
	 * A complex situation to test the correctness
	 */
	@Test public void testReduceTrackWithObjects() {
		CircularOrbit<CentralObject, PhysicalObject> circularOrbitInstance = emptyInstance();
		Track track_1 = new Track("track_1", 1);
		Track track_2 = new Track("track_2", 2);
		Track track_3 = new Track("track_3", 3);
		Track track_4 = new Track("track_4", 4);
		Track track_5 = new Track("track_5", 5);
		circularOrbitInstance.addTrack(track_1);
		circularOrbitInstance.addTrack(track_2);
		circularOrbitInstance.addTrack(track_3);
		circularOrbitInstance.addTrack(track_4);
		assertEquals("the size of tracks should be 4", 4,
		             circularOrbitInstance.getTracks().size());
		Planet object_1 = new Planet();
		Planet object_2 = new Planet("Earth_1", "solid", "blue", 1.27e4, 1.5e9, 30, "CW", 0);
		Planet object_3 = new Planet("Earth_2", "solid", "blue", 1.27e4, 1.5e9, 30, "CW", 0);
		Planet object_4 = new Planet("Earth_3", "solid", "blue", 1.27e4, 1.5e9, 30, "CW", 0);
		circularOrbitInstance.addObject(track_1, object_1);
		circularOrbitInstance.addObject(track_2, object_2);
		circularOrbitInstance.addObject(track_3, object_3);
		circularOrbitInstance.addObject(track_4, object_4);
		assertEquals("the size of orbit objects should be 4", 4,
		             circularOrbitInstance.getPhysicalObjects().size());
		Stellar stellar = new Stellar("Sun", 7.2e5, 2e30);
		circularOrbitInstance.setCentralObject(stellar);
		circularOrbitInstance.addRelationOfCentralPhysical(object_1);
		circularOrbitInstance.addRelationOfCentralPhysical(object_2);
		circularOrbitInstance.addRelationOfPhysicalObject(object_1, object_2);
		circularOrbitInstance.addRelationOfPhysicalObject(object_1, object_3);
		circularOrbitInstance.addRelationOfPhysicalObject(object_1, object_4);
		circularOrbitInstance.addRelationOfPhysicalObject(object_2, object_4);
		assertTrue("Sun has relation with object_1", circularOrbitInstance.hasRelation(object_1));
		assertTrue("successfully remove track_1", circularOrbitInstance.removeTrack(track_1));
		assertFalse("fail to remove track_5", circularOrbitInstance.removeTrack(track_5));
		assertEquals("the size of physical objects should be 3", 3,
		             circularOrbitInstance.getPhysicalObjects().size());
		assertFalse("central object has no relation with object_1",
		            circularOrbitInstance.hasRelation(object_1));
		assertFalse("object_1 does not have related physical objects",
		            circularOrbitInstance.hasRelation(object_1, object_2) ||
				            circularOrbitInstance.hasRelation(object_1, object_3) ||
				            circularOrbitInstance.hasRelation(object_1, object_4));
	}
	
	/**
	 * Method: addObject(Track target, E physicalObject)
	 */
	@Test public void testAddObject() {
		CircularOrbit<CentralObject, PhysicalObject> circularOrbitInstance = emptyInstance();
		Track track_1 = new Track("track_1", 1);
		Track track_2 = new Track("track_2", 2);
		Track track_3 = new Track("track_3", 3);
		Track track_4 = new Track("track_4", 4);
		Track track_5 = new Track("track_5", 5);
		circularOrbitInstance.addTrack(track_1);
		circularOrbitInstance.addTrack(track_2);
		circularOrbitInstance.addTrack(track_3);
		circularOrbitInstance.addTrack(track_4);
		Planet object_1 = new Planet();
		Planet object_2 = new Planet("Earth_1", "solid", "blue", 1.27e4, 1.5e9, 30, "CW", 0);
		Planet object_3 = new Planet("Earth_2", "solid", "blue", 1.27e4, 1.5e9, 30, "CW", 0);
		Planet object_4 = new Planet("Earth_3", "solid", "blue", 1.27e4, 1.5e9, 30, "CW", 0);
		circularOrbitInstance.addObject(track_1, object_1);
		circularOrbitInstance.addObject(track_2, object_2);
		circularOrbitInstance.addObject(track_3, object_3);
		circularOrbitInstance.addObject(track_4, object_4);
		assertEquals("The size of orbit objects should be 4", 4,
		             circularOrbitInstance.getPhysicalObjects().size());
		assertFalse("can't add a object to a track that do not exist",
		            circularOrbitInstance.addObject(track_5, object_1));
	}
	
	/**
	 * Method removeObject(E physicalObject)
	 */
	@Test public void testRemoveObject() {
		CircularOrbit<CentralObject, PhysicalObject> circularOrbitInstance = emptyInstance();
		Track track_1 = new Track("track_1", 1);
		Track track_2 = new Track("track_2", 2);
		Track track_3 = new Track("track_3", 3);
		Track track_4 = new Track("track_4", 4);
		circularOrbitInstance.addTrack(track_1);
		circularOrbitInstance.addTrack(track_2);
		circularOrbitInstance.addTrack(track_3);
		circularOrbitInstance.addTrack(track_4);
		assertEquals("the size of tracks should be 4", 4,
		             circularOrbitInstance.getTracks().size());
		Planet object_1 = new Planet();
		Planet object_2 = new Planet("Earth_1", "solid", "blue", 1.27e4, 1.5e9, 30, "CW", 0);
		Planet object_3 = new Planet("Earth_2", "solid", "blue", 1.27e4, 1.5e9, 30, "CW", 0);
		Planet object_4 = new Planet("Earth_3", "solid", "blue", 1.27e4, 1.5e9, 30, "CW", 0);
		Planet object_5 = new Planet("Earth_4", "solid", "blue", 1.27e4, 1.5e9, 40, "CW", 0);
		circularOrbitInstance.addObject(track_1, object_1);
		circularOrbitInstance.addObject(track_2, object_2);
		circularOrbitInstance.addObject(track_3, object_3);
		circularOrbitInstance.addObject(track_4, object_4);
		assertEquals("the size of orbit objects should be 4", 4,
		             circularOrbitInstance.getPhysicalObjects().size());
		Stellar stellar = new Stellar("Sun", 7.2e5, 2e30);
		circularOrbitInstance.setCentralObject(stellar);
		circularOrbitInstance.addRelationOfCentralPhysical(object_1);
		circularOrbitInstance.addRelationOfCentralPhysical(object_2);
		circularOrbitInstance.addRelationOfPhysicalObject(object_1, object_2);
		circularOrbitInstance.addRelationOfPhysicalObject(object_1, object_3);
		circularOrbitInstance.addRelationOfPhysicalObject(object_1, object_4);
		circularOrbitInstance.addRelationOfPhysicalObject(object_2, object_4);
		assertTrue("successfully remove object_1", circularOrbitInstance.removeObject(object_1));
		assertFalse("fail to remove object_5", circularOrbitInstance.removeObject(object_5));
		assertEquals("the size of physical objects should be 3", 3,
		             circularOrbitInstance.getPhysicalObjects().size());
		assertFalse("central object has no relation with object_1",
		            circularOrbitInstance.hasRelation(object_1));
		assertFalse("object_1 does not have related physical objects",
		            circularOrbitInstance.hasRelation(object_1, object_2) ||
				            circularOrbitInstance.hasRelation(object_1, object_3) ||
				            circularOrbitInstance.hasRelation(object_1, object_4));
		assertFalse("object_1 does not have related track",
		            circularOrbitInstance.hasRelation(object_1, track_1));
	}
	
	/**
	 * Method: addRelationOfCentralPhysical(L centralObject, E physicalObject)
	 */
	@Test public void addRelationOfCentralPhysical() {
		CircularOrbit<CentralObject, PhysicalObject> circularOrbitInstance = emptyInstance();
		Track track_1 = new Track("track_1", 1);
		Track track_2 = new Track("track_2", 2);
		Track track_3 = new Track("track_3", 3);
		Track track_4 = new Track("track_4", 4);
		Track track_5 = new Track("track_5", 5);
		circularOrbitInstance.addTrack(track_1);
		circularOrbitInstance.addTrack(track_2);
		circularOrbitInstance.addTrack(track_3);
		circularOrbitInstance.addTrack(track_4);
		assertEquals("the size of tracks should be 4", 4,
		             circularOrbitInstance.getTracks().size());
		Planet object_1 = new Planet();
		Planet object_2 = new Planet("Earth_1", "solid", "blue", 1.27e4, 1.5e9, 30, "CW", 0);
		Planet object_3 = new Planet("Earth_2", "solid", "blue", 1.27e4, 1.5e9, 30, "CW", 0);
		Planet object_4 = new Planet("Earth_3", "solid", "blue", 1.27e4, 1.5e9, 30, "CW", 0);
		circularOrbitInstance.addObject(track_1, object_1);
		circularOrbitInstance.addObject(track_2, object_2);
		circularOrbitInstance.addObject(track_3, object_3);
		circularOrbitInstance.addObject(track_4, object_4);
		assertEquals("the size of orbit objects should be 4", 4,
		             circularOrbitInstance.getPhysicalObjects().size());
		Stellar stellar = new Stellar("Sun", 7.2e5, 2e30);
		circularOrbitInstance.setCentralObject(stellar);
		circularOrbitInstance.addRelationOfCentralPhysical(object_1);
		circularOrbitInstance.addRelationOfCentralPhysical(object_2);
		circularOrbitInstance.addRelationOfPhysicalObject(object_1, object_2);
		circularOrbitInstance.addRelationOfPhysicalObject(object_1, object_3);
		circularOrbitInstance.addRelationOfPhysicalObject(object_1, object_4);
		circularOrbitInstance.addRelationOfPhysicalObject(object_2, object_4);
		assertTrue("Sun has relation with object_1", circularOrbitInstance.hasRelation(object_1));
		assertTrue("Sun has relation with object_1",
		           circularOrbitInstance.getRelatedPhysicalObjects().contains(object_1));
	}
	
	/**
	 * Method: addRelationOfPhysicalObject(E physicalObject_1, E physicalObject_2)
	 */
	@Test public void addRelationOfPhysicalObject() {
		CircularOrbit<CentralObject, PhysicalObject> circularOrbitInstance = emptyInstance();
		Track track_1 = new Track("track_1", 1);
		Track track_2 = new Track("track_2", 2);
		Track track_3 = new Track("track_3", 3);
		Track track_4 = new Track("track_4", 4);
		Track track_5 = new Track("track_5", 5);
		circularOrbitInstance.addTrack(track_1);
		circularOrbitInstance.addTrack(track_2);
		circularOrbitInstance.addTrack(track_3);
		circularOrbitInstance.addTrack(track_4);
		assertEquals("the size of tracks should be 4", 4,
		             circularOrbitInstance.getTracks().size());
		Planet object_1 = new Planet();
		Planet object_2 = new Planet("Earth_1", "solid", "blue", 1.27e4, 1.5e9, 30, "CW", 0);
		Planet object_3 = new Planet("Earth_2", "solid", "blue", 1.27e4, 1.5e9, 30, "CW", 0);
		Planet object_4 = new Planet("Earth_3", "solid", "blue", 1.27e4, 1.5e9, 30, "CW", 0);
		circularOrbitInstance.addObject(track_1, object_1);
		circularOrbitInstance.addObject(track_2, object_2);
		circularOrbitInstance.addObject(track_3, object_3);
		circularOrbitInstance.addObject(track_4, object_4);
		assertEquals("the size of orbit objects should be 4", 4,
		             circularOrbitInstance.getPhysicalObjects().size());
		Stellar stellar = new Stellar("Sun", 7.2e5, 2e30);
		circularOrbitInstance.setCentralObject(stellar);
		circularOrbitInstance.addRelationOfCentralPhysical(object_1);
		circularOrbitInstance.addRelationOfCentralPhysical(object_2);
		circularOrbitInstance.addRelationOfPhysicalObject(object_1, object_2);
		circularOrbitInstance.addRelationOfPhysicalObject(object_1, object_3);
		circularOrbitInstance.addRelationOfPhysicalObject(object_1, object_4);
		circularOrbitInstance.addRelationOfPhysicalObject(object_2, object_4);
		assertTrue("object_1 has related physical objects",
		           circularOrbitInstance.hasRelation(object_1, object_2) &&
				           circularOrbitInstance.hasRelation(object_1, object_3) &&
				           circularOrbitInstance.hasRelation(object_1, object_4));
		assertTrue("successfully remove track_1", circularOrbitInstance.removeTrack(track_1));
		assertEquals("the size of orbit objects should be 3", 3,
		             circularOrbitInstance.getPhysicalObjects().size());
		assertFalse("central object has no relation with object_1",
		            circularOrbitInstance.hasRelation(object_1));
		assertFalse("object_1 does not have related physical objects",
		            circularOrbitInstance.hasRelation(object_1, object_2) ||
				            circularOrbitInstance.hasRelation(object_1, object_3) ||
				            circularOrbitInstance.hasRelation(object_1, object_4));
	}
	
	/**
	 * Method: transit(E physicalObject, Track track)
	 */
	@Test public void testTransit() {
		CircularOrbit<CentralObject, PhysicalObject> circularOrbitInstance = emptyInstance();
		Track track_1 = new Track("track_1", 1);
		Track track_2 = new Track("track_2", 2);
		circularOrbitInstance.addTrack(track_1);
		circularOrbitInstance.addTrack(track_2);
		Planet object_1 = new Planet();
		Planet object_2 = new Planet("Earth_1", "solid", "blue", 1.27e4, 1.5e9, 30, "CW", 0);
		Planet object_3 = new Planet("Earth_2", "solid", "blue", 1.27e4, 1.5e9, 30, "CW", 0);
		circularOrbitInstance.addObject(track_1, object_1);
		circularOrbitInstance.addObject(track_2, object_2);
		assertEquals("the size of physical objects should be 2", 2,
		             circularOrbitInstance.getPhysicalObjects().size());
		circularOrbitInstance.transit(object_1, track_2);
		assertEquals("track_2 has object_1", track_2,
		             circularOrbitInstance.getTrackOfObject(object_1));
		assertFalse("track_1 has not relation with object_1",
		            circularOrbitInstance.hasRelation(object_1, track_1));
		assertFalse("Can't transit object does not exist",
		            circularOrbitInstance.transit(object_3, track_1));
	}
}