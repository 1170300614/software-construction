package applications;

import circularOrbit.CircularOrbitHelper;
import physicalObject.App;

public class Main {
	public static void main(String[] args) throws Exception {
		StellarSystem stellarSystem =
				new StellarSystem().buildStellarSystemFromFile("test/StellarSystem.txt");
		AtomStructure atomStructure =
				new AtomStructure().buildAtomStructureFromFile("test/AtomicStructure.txt");
		PersonalAppEcosystem personalAppEcosystem =
				new PersonalAppEcosystem().buildPersonalAppEcosystemFromFile(
						"test/PersonalAppEcosystem_Medium.txt");
		CircularOrbitHelper circularOrbitHelper = new CircularOrbitHelper();
		//circularOrbitHelper.visualize(personalAppEcosystem);
		System.out.println(15 / 10);
		stellarSystem.getPosition(1498328);
		App app_1 =
				new App("App44", "BRHVEG", "v74-69-66", "ImonnsFcwTAs87oBvYdrLNqBc9K58ZMD8qpk4qWZ",
				        "Video", 0);
		App app_2 = new App("App130", "BHPVC", "v20", "xh2TooROqBxjCPC8GsTT1YswMljtuc5rGHcj0arj",
		                    "Music", 0);
		System.out.println(
				personalAppEcosystem.getLogicalDistance(personalAppEcosystem, app_1, app_2));
		
	}
}