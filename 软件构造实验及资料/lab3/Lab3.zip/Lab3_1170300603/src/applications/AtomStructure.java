package applications;

import centralObject.Core;
import circularOrbit.ConcreteCircularOrbit;
import physicalObject.Electronic;
import track.Track;

import java.io.BufferedReader;
import java.io.FileNotFoundException;
import java.io.FileReader;
import java.util.List;
import java.util.Random;
import java.util.regex.Matcher;
import java.util.regex.Pattern;
import java.util.stream.Collectors;

/**
 * Concrete Atom System
 */
public class AtomStructure extends ConcreteCircularOrbit<Core, Electronic> {
	//builder
	public AtomStructure() {}
	
	/**
	 * build the stellar system from the file
	 *
	 * @param fileName file name
	 * @return the new atom system build by the file
	 * @throws FileNotFoundException if file is not found
	 */
	public AtomStructure buildAtomStructureFromFile(String fileName) throws FileNotFoundException {
		int numberOfTracks = 0;
		List<String> lineData =
				new BufferedReader((new FileReader(fileName))).lines().collect(Collectors.toList());
		Pattern pattern = Pattern.compile("([a-zA-Z]+)\\s::=\\s(\\w+)");
		for (String line: lineData) {
			if (line != null) {
				Matcher matcher = pattern.matcher(line);
				if (matcher.find()) {
					if (matcher.group(1).equals("NumberOfTracks")) {
						numberOfTracks = Integer.parseInt(matcher.group(2));
						break;
					}
				}
			}
		}
		for (String line: lineData) {
			if (line != null) {
				Matcher matcher = pattern.matcher(line);
				if (matcher.find()) {
					if (matcher.group(1).equals("ElementName")) {
						buildAtomStructure(lineData, numberOfTracks);
						return this;
					}
				}
			}
		}
		return this;
	}
	
	/**
	 * build the system by the data
	 *
	 * @param lineData standard data
	 */
	private void buildAtomStructure(List<String> lineData, int numberOfTracks) {
		Pattern pattern = Pattern.compile("([a-zA-Z]+)\\s::=\\s([A-Z][a-z]?|[\\d;/]+)");
		for (String line: lineData)
			if (line != null) {
				Matcher matcher = pattern.matcher(line);
				if (matcher.find()) {
					if (matcher.group(1).equals("ElementName")) {
						buildCore(matcher.group(2));
					} else if (matcher.group(1).equals("NumberOfElectron")) {
						buildElectronic(numberOfTracks, matcher.group(2));
					}
				}
			}
	}
	
	/**
	 * build a core from the data
	 *
	 * @param coreData the core
	 */
	private void buildCore(String coreData) {
		Core core = new Core(coreData);
		setCentralObject(core);
	}
	
	/**
	 * build a electronic from the data
	 *
	 * @param numberOfTracks number of the track
	 * @param trackData      standard data
	 */
	private void buildElectronic(int numberOfTracks, String trackData) {
		String[] args = trackData.split("[;/]");
		assert args.length == numberOfTracks * 2;
		for (int i = 0; i < 2 * numberOfTracks; i += 2) {
			Track track = new Track(Integer.toString(i / 2));
			addTrack(track);
			for (int j = 0; j < Integer.parseInt(args[i + 1]); j++) {
				Electronic electronic =
						new Electronic(Integer.toString(j + 1), new Random().nextDouble() % 360);
				addObject(track, electronic);
			}
		}
	}
}