package applications;

import centralObject.Stellar;
import circularOrbit.ConcreteCircularOrbit;
import physicalObject.Planet;
import track.Track;

import java.io.BufferedReader;
import java.io.FileNotFoundException;
import java.io.FileReader;
import java.util.List;
import java.util.regex.Matcher;
import java.util.regex.Pattern;
import java.util.stream.Collectors;

/**
 * Concrete Stellar System
 */
public class StellarSystem extends ConcreteCircularOrbit<Stellar, Planet> {
	//builder
	public StellarSystem() {}
	
	private void checkRep() {
		//every track has a planet
		for (Track track: getTracks()) {
			assert getPhysicalObjectsOnTrack(track).size() == 1;
		}
	}
	
	/**
	 * build the stellar system from the file
	 *
	 * @param fileName file name
	 * @return the new stellar system build by the file
	 * @throws FileNotFoundException if file is not found
	 */
	public StellarSystem buildStellarSystemFromFile(String fileName) throws FileNotFoundException {
		List<String> lineData =
				new BufferedReader((new FileReader(fileName))).lines().collect(Collectors.toList());
		Pattern pattern = Pattern.compile("([a-zA-Z]+)\\s::=");
		for (String line: lineData) {
			if (line != null) {
				Matcher matcher = pattern.matcher(line);
				if (matcher.find()) {
					if (matcher.group(1).equals("Stellar")) {
						buildStellarSystem(lineData);
						checkRep();
						return this;
					}
				}
			}
		}
		checkRep();
		return this;
	}
	
	/**
	 * get the azimuth by the given time
	 *
	 * @param planet a
	 * @param time   running time
	 * @return new azimuth
	 */
	public double move(Planet planet, double time) {
		if (!physicalObjects.contains(planet))
			return -1;
		double oldValue = planet.getAzimuth();
		if (planet.getOrientation().equals("CW")) {
			return (oldValue + planet.getRevolutionSpeed() * time) % 360;
		} else {
			return (oldValue - planet.getRevolutionSpeed() * time) % 360 + 360;
		}
	}
	
	/**
	 * output the position with given time
	 *
	 * @param time given time
	 */
	public void getPosition(double time) {
		System.out.println("Position of Planets After " + time + " Time");
		System.out.printf("%-15s %-15s %-15s\n", "NAME", "ORBIT RADIUS", "AZIMUTH");
		for (Planet planet: physicalObjects) {
			System.out.printf("%-15s %-15.2e %-15.2f\n", planet.getLabel(),
			                  planet.getOrbitRadius(),
			                  move(planet, time));
		}
	}
	
	/**
	 * build the system by the data
	 *
	 * @param lineData standard data
	 */
	private void buildStellarSystem(List<String> lineData) {
		Pattern pattern = Pattern.compile("([a-zA-Z]+)\\s::=\\s<([^<>]+)>");
		for (String line: lineData) {
			if (line != null) {
				Matcher matcher = pattern.matcher(line);
				if (matcher.find()) {
					if (matcher.group(1).equals("Stellar")) {
						buildStellar(matcher.group(2));
					} else if (matcher.group(1).equals("Planet")) {
						buildPlanet(matcher.group(2));
					}
				}
			}
		}
	}
	
	/**
	 * build a stellar from the data
	 *
	 * @param stellarData standard data
	 */
	private void buildStellar(String stellarData) {
		String regex = "(\\w+)\\s?,\\s?([1-9]\\d{0,3}(.\\d+)?|[1-9](.\\d+)?(e\\d+)?)\\s?,\\s?" +
				"([1-9]\\d{0,3}(.\\d+)?|[1-9](.\\d+)?(e\\d+)?)";
		Pattern pattern = Pattern.compile(regex);
		Matcher matcher = pattern.matcher(stellarData);
		if (matcher.find()) {
			setCentralObject(new Stellar(matcher.group(1), Double.parseDouble(matcher.group(2)),
			                             Double.parseDouble(matcher.group(6))));
		}
	}
	
	/**
	 * build a planet from the data
	 *
	 * @param planetData standard data
	 */
	private void buildPlanet(String planetData) {
		String regex =
				"(\\w+)\\s?,\\s?(\\w+)\\s?,\\s?(\\w+)\\s?,\\s?(\\d{0,4}(.\\d+)?|[1-9](.\\d+)?" +
						"(e\\d+)?)\\s?,\\s?(\\d{0,4}(.\\d+)?|[1-9]0?(.\\d+)?(e\\d+)?)\\s?,\\s?" +
						"(\\d{0,4}(.\\d+)?|[1-9](.\\d+)?(e\\d+)?)\\s?,\\s?(CC?W)\\s?,\\s?(360(" +
						".0+)?|3[0-5]\\d(.\\d+)?|[12]\\d{2}(.\\d+)?|[1-9]\\d(.\\d+)?|\\d(.\\d+)?)";
		Pattern pattern = Pattern.compile(regex);
		Matcher matcher = pattern.matcher(planetData);
		if (matcher.find()) {
			Track track = new Track("Track", Double.parseDouble(matcher.group(8)));
			Planet planet = new Planet(matcher.group(1), matcher.group(2), matcher.group(3),
			                           Double.parseDouble(matcher.group(4)),
			                           Double.parseDouble(matcher.group(8)),
			                           Double.parseDouble(matcher.group(12)), matcher.group(16),
			                           Double.parseDouble(matcher.group(17)));
			addTrack(track);
			addObject(track, planet);
		}
	}
}