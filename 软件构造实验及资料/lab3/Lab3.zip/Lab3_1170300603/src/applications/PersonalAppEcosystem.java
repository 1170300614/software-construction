package applications;

import centralObject.User;
import circularOrbit.ConcreteCircularOrbit;
import physicalObject.App;
import track.Track;

import java.io.BufferedReader;
import java.io.FileNotFoundException;
import java.io.FileReader;
import java.text.ParseException;
import java.text.SimpleDateFormat;
import java.util.*;
import java.util.regex.Matcher;
import java.util.regex.Pattern;
import java.util.stream.Collectors;

/**
 * Concrete Personal App Ecosystem
 */
public class PersonalAppEcosystem extends ConcreteCircularOrbit<User, App> {
	private final Map<App, List<Date>> installLog = new HashMap<>();
	private final Map<App, List<Date>> usageLog = new HashMap<>();
	private final Map<App, List<Date>> uninstallLog = new HashMap<>();
	private final Map<App, Integer> usageTime = new HashMap<>();
	private final List<Log> segmentLog = new ArrayList<>();
	private final int rank = 10;
	private String period;
	private Date startTime;
	private Date endTime;
	
	//builder
	public PersonalAppEcosystem() {}
	
	private void checkRep() { assert installLog.size() >= usageLog.size(); }
	
	public Map<App, List<Date>> getInstallLog() { return installLog; }
	
	public Map<App, List<Date>> getUsageLog() { return usageLog; }
	
	public Map<App, List<Date>> getUninstallLog() { return uninstallLog; }
	
	public Map<App, Integer> getUsageTime() { return usageTime; }
	
	public String getPeriod() { return period; }
	
	public Date getStartTime() { return startTime; }
	
	public Date getEndTime() { return endTime; }
	
	/**
	 * build the personal app ecosystem from the file
	 *
	 * @param fileName file name
	 * @return the new personal app ecosystem build by the file
	 * @throws FileNotFoundException if file is not found
	 */
	public PersonalAppEcosystem buildPersonalAppEcosystemFromFile(String fileName)
			throws FileNotFoundException, ParseException {
		List<String> lineData =
				new BufferedReader((new FileReader(fileName))).lines().collect(Collectors.toList());
		Pattern pattern = Pattern.compile("([A-Za-z]+)\\s::=");
		for (String line: lineData) {
			Matcher matcher = pattern.matcher(line);
			if (matcher.find()) {
				if (matcher.group(1).equals("User")) {
					buildPersonalAppEcosystem(lineData);
					arrange();
					checkRep();
					return this;
				}
			}
		}
		return this;
	}
	
	/**
	 * build the system by the data
	 *
	 * @param lineData standard data
	 */
	private void buildPersonalAppEcosystem(List<String> lineData) throws ParseException {
		Track[] track = new Track[10];
		for (int i = 0; i < rank; i++) {
			track[i] = new Track("Track_".concat(Integer.toString(i + 1)), i + 1);
			addTrack(track[i]);
		}
		Pattern pattern = Pattern.compile("([A-Za-z]+)\\s::=\\s<?([^<>]+)>?");
		for (String lineDatum: lineData) {
			if (lineDatum != null) {
				Matcher matcher = pattern.matcher(lineDatum);
				if (matcher.find()) {
					switch (matcher.group(1)) {
						case "User":
							buildUser(matcher.group(2));
							break;
						case "Period":
							period = matcher.group(2);
							break;
						case "App":
							buildApp(matcher.group(2), track[9]);
							break;
					}
				}
			}
		}
		for (String lineDatum: lineData) {
			if (lineDatum != null) {
				Matcher matcher = pattern.matcher(lineDatum);
				if (matcher.find()) {
					switch (matcher.group(1)) {
						case "Relation":
							addRelation(matcher.group(2));
							break;
						case "InstallLog":
							addInstallLog(matcher.group(2));
							break;
						case "UsageLog":
							addUsageLog(matcher.group(2));
							break;
						case "UninstallLog":
							addUninstallLog(matcher.group(2));
							break;
					}
				}
			}
		}
		this.startTime = getEarliestTime();
		this.endTime = getLatestTime();
	}
	
	/**
	 * generate the systems attend to the install and uninstall app interval
	 *
	 * @throws ParseException convert exception
	 */
	private void generateSegmentLog() throws ParseException {
		List<Date> dateList = getIntervalTimeList();
		//		List<Map.Entry<App, Integer>> installInfo = new ArrayList<>(usageTime.entrySet());
		//		installInfo.sort((i1, i2)->i2.getValue().compareTo(i1.getValue()));
		//		List<Map.Entry<App, Integer>> usageInfo = new ArrayList<>(usageTime.entrySet());
		//		usageInfo.sort((i1, i2)->i2.getValue().compareTo(i1.getValue()));
		//		List<Map.Entry<App, Integer>> uninstallInfo = new ArrayList<>(usageTime.entrySet
		//		());
		//		uninstallInfo.sort((i1, i2)->i2.getValue().compareTo(i1.getValue()));
		for (int i = 0; i < dateList.size() - 1; i++) {
			Log log = new Log();
			log.setStartTime(dateList.get(i));
			log.setEndTime(dateList.get(i + 1));
			for (App app: installLog.keySet()) {
				for (Date date: installLog.get(app)) {
					if (date.after(dateList.get(i)) && date.before(dateList.get(i + 1))) {
						log.addInstallLog(app, date);
					}
				}
			}
			for (App app: usageLog.keySet()) {
				for (Date date: usageLog.get(app)) {
					if (date.after(dateList.get(i)) && date.before(dateList.get(i + 1))) {
						log.addUsageLog(app, date);
					}
				}
			}
			for (App app: uninstallLog.keySet()) {
				for (Date date: uninstallLog.get(app)) {
					if (date.after(dateList.get(i)) && date.before(dateList.get(i + 1))) {
						log.addUninstallLog(app, date);
					}
				}
			}
		}
	}
	
	/**
	 * get the earliest time that app installed and latest time app uninstalled
	 *
	 * @return the earliest time that app installed and latest time app uninstalled
	 * @throws ParseException convert exception
	 */
	public List<Date> getIntervalTimeList() throws ParseException {
		SimpleDateFormat simpleDateFormat = new SimpleDateFormat("yyyy-MM-dd");
		Date start = simpleDateFormat.parse(getEarliestTime().toString());
		Date end = simpleDateFormat.parse(getLatestTime().toString());
		List<Date> timeList = new ArrayList<>();
		while (start.getTime() <= end.getTime()) {
			timeList.add(start);
			Calendar calendar = Calendar.getInstance();
			calendar.setTime(start);
			switch (period) {
				case "Month":
					calendar.add(Calendar.MONTH, 1);
					break;
				case "Week":
					calendar.add(Calendar.WEEK_OF_MONTH, 1);
					break;
				case "Day":
					calendar.add(Calendar.DAY_OF_WEEK, 1);
					break;
				case "Hour":
					calendar.add(Calendar.HOUR, 1);
					break;
				default:
					return null;
			}
			if (calendar.getTime().getTime() > end.getTime()) {
				if (!start.equals(end)) {
					timeList.add(end);
				}
				start = calendar.getTime();
			} else {
				start = calendar.getTime();
			}
		}
		return timeList;
	}
	
	/**
	 * get the earliest time of the install log
	 *
	 * @return the earliest time of the install log
	 */
	private Date getEarliestTime() {
		Date date = new Date();
		for (Map.Entry<App, List<Date>> entry: usageLog.entrySet()) {
			if (entry.getValue().size() > 0) {
				date = entry.getValue().get(0);
				break;
			}
		}
		for (Map.Entry<App, List<Date>> entry: installLog.entrySet()) {
			entry.getValue().sort(Comparator.naturalOrder());
			if (entry.getValue().size() > 0) {
				if (date.after(entry.getValue().get(0))) {
					date = entry.getValue().get(0);
				}
			}
		}
		return date;
	}
	
	/**
	 * get the latest time of the install log
	 *
	 * @return the latest time of the install log
	 */
	private Date getLatestTime() {
		Date date = new Date();
		for (Map.Entry<App, List<Date>> entry: usageLog.entrySet()) {
			if (entry.getValue().size() > 0) {
				date = entry.getValue().get(0);
				break;
			}
		}
		for (Map.Entry<App, List<Date>> entry: uninstallLog.entrySet()) {
			entry.getValue().sort(Comparator.reverseOrder());
			if (entry.getValue().size() > 0) {
				if (date.before(entry.getValue().get(0))) {
					date = entry.getValue().get(0);
				}
			}
		}
		return date;
	}
	
	/**
	 * build a user from the data
	 *
	 * @param userData standard data
	 */
	private void buildUser(String userData) {
		User user = new User(userData);
		setCentralObject(user);
	}
	
	/**
	 * build the objects from the standard data
	 *
	 * @param appData data of every app
	 * @param track   target track
	 */
	private void buildApp(String appData, Track track) {
		String regex =
				"(\\w+)\\s?,\\s?(\\w+)\\s?,\\s?([vV\\d.-_]+|(ver)?[vV\\d.-_]+(ver)?[vV\\d.-_]+)" +
						"\\s?,\\s?\"([\\w\\s]+)\"\\s?,\\s?\"([\\w\\s]+)\"";
		Pattern pattern = Pattern.compile(regex);
		Matcher matcher = pattern.matcher(appData);
		if (matcher.find()) {
			App app =
					new App(matcher.group(1), matcher.group(2), matcher.group(3), matcher.group(6),
					        matcher.group(7), 0);
			addObject(track, app);
			installLog.put(app, new ArrayList<>());
			usageLog.put(app, new ArrayList<>());
			uninstallLog.put(app, new ArrayList<>());
			usageTime.put(app, 0);
		}
	}
	
	/**
	 * add app relation from the data
	 *
	 * @param appData standard data of relation
	 */
	private void addRelation(String appData) {
		String regex = "(\\w+)\\s?,\\s?(\\w+)";
		Pattern pattern = Pattern.compile(regex);
		Matcher matcher = pattern.matcher(appData);
		Set<App> apps = getPhysicalObjects();
		if (matcher.find()) {
			for (App app_1: apps) {
				if (app_1.getLabel().equals(matcher.group(1))) {
					for (App app_2: apps) {
						if (app_2.getLabel().equals(matcher.group(2))) {
							addRelationOfPhysicalObject(app_1, app_2);
							return;
						}
					}
				}
			}
		}
	}
	
	/**
	 * add a install log
	 *
	 * @param installData standard data
	 * @throws ParseException convert exception
	 */
	private void addInstallLog(String installData) throws ParseException {
		String regex =
				"([12]\\d{3}-[01]\\d-[0-3]\\d)\\s?,\\s?([012]\\d:[0-5]\\d:[0-5]\\d)\\s?,\\s?" +
						"(\\w+)";
		Pattern pattern = Pattern.compile(regex);
		Matcher matcher = pattern.matcher(installData);
		if (matcher.find()) {
			String time = matcher.group(1) + " " + matcher.group(2);
			SimpleDateFormat simpleDateFormat = new SimpleDateFormat("yyyy-MM-dd HH:mm:ss");
			for (App app: getPhysicalObjects()) {
				if (app.getLabel().equals(matcher.group(3))) {
					Date date = simpleDateFormat.parse(time);
					installLog.get(app).add(date);
					break;
				}
			}
		}
	}
	
	/**
	 * add a usage log
	 *
	 * @param usageData standard data
	 * @throws ParseException convert exception
	 */
	private void addUsageLog(String usageData) throws ParseException {
		String regex =
				"([12]\\d{3}-[01]\\d-[0-3]\\d)\\s?,\\s?([012]\\d:[0-5]\\d:[0-5]\\d)\\s?,\\s?(\\w+)" +
						"\\s?,\\s?(\\d+)";
		Pattern pattern = Pattern.compile(regex);
		Matcher matcher = pattern.matcher(usageData);
		if (matcher.find()) {
			String time = matcher.group(1) + " " + matcher.group(2);
			SimpleDateFormat simpleDateFormat = new SimpleDateFormat("yyyy-MM-dd HH:mm:ss");
			for (App app: getPhysicalObjects()) {
				if (app.getLabel().equals(matcher.group(3))) {
					Date date = simpleDateFormat.parse(time);
					usageLog.get(app).add(date);
					int oldTime = usageTime.get(app);
					usageTime.replace(app, oldTime + Integer.parseInt(matcher.group(4)));
					break;
				}
			}
		}
	}
	
	/**
	 * add a uninstall log
	 *
	 * @param uninstallData standard data
	 * @throws ParseException convert exception
	 */
	private void addUninstallLog(String uninstallData) throws ParseException {
		String regex =
				"([12]\\d{3}-[01]\\d-[0-3]\\d)\\s?,\\s?([012]\\d:[0-5]\\d:[0-5]\\d)\\s?,\\s?" +
						"(\\w+)";
		Pattern pattern = Pattern.compile(regex);
		Matcher matcher = pattern.matcher(uninstallData);
		if (matcher.find()) {
			String time = matcher.group(1) + " " + matcher.group(2);
			SimpleDateFormat simpleDateFormat = new SimpleDateFormat("yyyy-MM-dd HH:mm:ss");
			for (App app: getPhysicalObjects()) {
				if (app.getLabel().equals(matcher.group(3))) {
					Date date = simpleDateFormat.parse(time);
					uninstallLog.get(app).add(date);
					break;
				}
			}
		}
	}
	
	/**
	 * to sort the app by the usage time and transit it to the correct track
	 */
	private void arrange() {
		List<Map.Entry<App, Integer>> info = new ArrayList<>(usageTime.entrySet());
		info.sort((i1, i2)->i2.getValue().compareTo(i1.getValue()));
		if (usageTime.size() <= rank) {
			for (int j = 0; j < info.size(); j++) {
				transit(info.get(j).getKey(), getTracks().get(j));
				j++;
			}
		} else {
			int sizePerTrack = usageTime.size() / rank;
			int j = 1, z = 0;
			for (Map.Entry<App, Integer> appIntegerEntry: info) {
				transit(appIntegerEntry.getKey(), getTracks().get(z));
				if (j < sizePerTrack && z < rank - 1) {
					j++;
				} else if (j >= sizePerTrack && z < rank - 1) {
					j = 1;
					z++;
				}
			}
		}
	}
}

/**
 * to store the app log in a period
 */
class Log {
	private final Map<App, List<Date>> installLog = new HashMap<>();
	private final Map<App, List<Date>> usageLog = new HashMap<>();
	private final Map<App, List<Date>> uninstallLog = new HashMap<>();
	private final Map<App, Integer> usageTime = new HashMap<>();
	private Date startTime;
	private Date endTime;
	
	//builder
	Log() {}
	
	public Map<App, List<Date>> getInstallLog() { return installLog; }
	
	public Map<App, List<Date>> getUsageLog() { return usageLog; }
	
	public Map<App, List<Date>> getUninstallLog() { return uninstallLog; }
	
	public Map<App, Integer> getUsageTime() { return usageTime; }
	
	public Date getStartTime() { return startTime; }
	
	public Date getEndTime() { return endTime; }
	
	/**
	 * to add a install log
	 *
	 * @param app  a app
	 * @param date install time
	 * @return true if add successfully
	 */
	boolean addInstallLog(App app, Date date) {
		if (!installLog.containsKey(app)) {
			installLog.put(app, new ArrayList<>());
			return installLog.get(app).add(date);
		} else {
			return installLog.get(app).add(date);
		}
	}
	
	/**
	 * to add a usage log
	 *
	 * @param app  a app
	 * @param date usage time
	 * @return true if add successfully
	 */
	boolean addUsageLog(App app, Date date) {
		if (!usageLog.containsKey(app)) {
			usageLog.put(app, new ArrayList<>());
			return usageLog.get(app).add(date);
		} else {
			return usageLog.get(app).add(date);
		}
	}
	
	/**
	 * to add a uninstall log
	 *
	 * @param app  a app
	 * @param date uninstall time
	 * @return true if add successfully
	 */
	boolean addUninstallLog(App app, Date date) {
		if (!uninstallLog.containsKey(app)) {
			uninstallLog.put(app, new ArrayList<>());
			return uninstallLog.get(app).add(date);
		} else {
			return uninstallLog.get(app).add(date);
		}
	}
	
	void setStartTime(Date startTime) { this.startTime = startTime; }
	
	void setEndTime(Date endTime) { this.endTime = endTime; }
}