package circularOrbit;

import centralObject.CentralObject;
import physicalObject.PhysicalObject;
import track.Track;

import javax.swing.*;
import java.awt.*;
import java.util.List;
import java.util.Set;

/**
 * GUI of Circular Orbit System
 */
public class CircularOrbitHelper {
	static CircularOrbit<CentralObject, PhysicalObject> circularOrbit;
	
	public CircularOrbitHelper() {}
	
	public void visualize(CircularOrbit c) {
		circularOrbit = c;
		final String TITLE = "Circular Orbit System";
		final int WIDTH = 900;
		final int HEIGHT = 900;
		JFrame jFrame = new JFrame();
		jFrame.setTitle(TITLE);
		jFrame.setSize(WIDTH, HEIGHT);
		jFrame.setDefaultCloseOperation(WindowConstants.EXIT_ON_CLOSE);
		jFrame.setLocationRelativeTo(null);
		JPanel jpanel = new JPanel() {
			@Override public void paint(Graphics graphics) {
				super.paint(graphics);
				int width = getWidth(); // total width
				int height = getHeight(); // total height
				List<Track> tracks = circularOrbit.getTracks();
				int numberOfTracks = tracks.size();
				double interval = (double) getWidth() / (double) (numberOfTracks + 1) / 2;
				int i = 0;
				jFrame.setTitle(TITLE);
				Graphics2D graphics2D = (Graphics2D) graphics.create();
				graphics2D.setRenderingHint(RenderingHints.KEY_ANTIALIASING,
				                            RenderingHints.VALUE_ANTIALIAS_ON);
				graphics2D.setColor(Color.RED);
				for (i = 1; i <= numberOfTracks; i++) {
					graphics2D.drawOval((int) (((double) width / 2 - i * interval)),
					                    (int) (((double) height / 2 - i * interval)),
					                    (int) (2 * i * interval), (int) (2 * i * interval));
				}
				graphics2D.setColor(Color.BLUE);
				graphics2D.setFont(new Font(null, Font.PLAIN, 12));
				graphics2D.drawString(circularOrbit.getCentralObject().getLabel(), 440, 440);
				i = 1;
				tracks.sort((track_1, track_2)->(int) (track_1.getRadius() - track_2.getRadius()));
				for (Track track: tracks) {
					for (PhysicalObject physicalObject: circularOrbit.getPhysicalObjectsOnTrack(
							track)) {
						int x = (int) ((double) width / 2 + i * (int) (interval) *
								Math.cos(Math.toRadians(physicalObject.getAzimuth() - 90)));
						int y = (int) ((double) width / 2 + i * (int) (interval - 10) *
								Math.sin(Math.toRadians(physicalObject.getAzimuth() - 90)));
						graphics2D.drawOval(x, y, 5, 5);
						graphics2D.drawString(physicalObject.getLabel(), x, y + 15);
						Set<PhysicalObject> relatedObjects =
								circularOrbit.getRelatedPhysicalObjects(physicalObject);
						for (PhysicalObject object: relatedObjects) {
							graphics2D.setColor(Color.GREEN);
							int x2 = (int) ((double) width / 2 +
									i * (int) ((double) width / (double) numberOfTracks / 2) *
											Math.cos(Math.toRadians(object.getAzimuth() - 90)));
							int y2 = (int) ((double) width / 2 +
									i * (int) ((double) width / (double) numberOfTracks / 2) *
											Math.sin(Math.toRadians(object.getAzimuth() - 90)));
							graphics2D.drawLine(x, y, x2, y2);
						}
					}
					i++;
				}
				graphics2D.dispose();
			}
		};
		jFrame.add(jpanel);
		jFrame.setSize(900, 900);
		jFrame.setVisible(true);
	}
}