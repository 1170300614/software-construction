package circularOrbit;

import track.Track;

import java.util.List;
import java.util.Set;

public interface CircularOrbit<L, E> {
	static <L, E> ConcreteCircularOrbit<L, E> empty() {
		return new ConcreteCircularOrbit<>();
	}
	
	/**
	 * Get tracks
	 *
	 * @return tracks
	 */
	List<Track> getTracks();
	
	/**
	 * Get central object
	 *
	 * @return centralObject
	 */
	L getCentralObject();
	
	/**
	 * Get physical objects and corresponding real-time azimuth
	 *
	 * @return physicalObjects and the corresponding azimuth
	 */
	Set<E> getPhysicalObjects();
	
	/**
	 * Add a new track
	 *
	 * @param track
	 */
	void addTrack(Track track);
	
	/**
	 * Reduce a track
	 *
	 * @param track target track
	 * @return false if can't find the track,
	 */
	boolean removeTrack(Track track);
	
	/**
	 * Add a central object
	 *
	 * @param centralObject a central object
	 */
	void setCentralObject(L centralObject);
	
	/**
	 * Add a object to the track
	 *
	 * @param target         target track
	 * @param physicalObject a physical object
	 * @return false if can't find target
	 */
	boolean addObject(Track target, E physicalObject);
	
	/**
	 * Remove given object
	 *
	 * @param physicalObject a physical object
	 * @return false if can't find target
	 */
	boolean removeObject(E physicalObject);
	
	/**
	 * Add relationship between the central object and a orbit object
	 *
	 * @param physicalObject a physical object
	 * @return if can't find the central object or orbit object, return false
	 */
	boolean addRelationOfCentralPhysical(E physicalObject);
	
	/**
	 * Add relationship between two orbit objects
	 *
	 * @param physicalObject_1 first physical objects
	 * @param physicalObject_2 second physical objects
	 * @return false if can't find two orbit objects
	 */
	boolean addRelationOfPhysicalObject(E physicalObject_1, E physicalObject_2);
	
	/**
	 * Determine if a physical object is on the given track
	 *
	 * @param centralObject the central object of the system
	 * @param track         given track
	 * @return true if there is a relation
	 */
	boolean hasRelation(E centralObject, Track track);
	
	/**
	 * Determine if there is a relation with the central object
	 *
	 * @param physicalObject a physical object
	 * @return true if there is a relation whit central object
	 */
	boolean hasRelation(E physicalObject);
	
	/**
	 * Determine if there is a relation between two physical objects
	 *
	 * @param physicalObject_1 first physical object
	 * @param physicalObject_2 second physical object
	 * @return true if there is a relation between two objects
	 */
	boolean hasRelation(E physicalObject_1, E physicalObject_2);
	
	/**
	 * Transit the orbit object to another track
	 *
	 * @param physicalObject a physical object
	 * @param target         target track
	 * @return false if can't find the object or the track
	 */
	boolean transit(E physicalObject, Track target);
	
	/**
	 * Get the current radius of a physical object
	 *
	 * @param physicalObject a physical object
	 * @return current radius
	 */
	double getRadius(E physicalObject);
	
	/**
	 * Get physical objects on the given track
	 *
	 * @param track
	 * @return physical objects on the track
	 */
	public Set<E> getPhysicalObjectsOnTrack(Track track);
	
	/**
	 * Get the track of the physical object
	 *
	 * @param physicalObject a physical object
	 * @return the track object on
	 */
	public Track getTrackOfObject(E physicalObject);
	
	/**
	 * Get related physical objects of the given physical object
	 *
	 * @param physicalObject
	 * @return related physical objects of the given physical object
	 */
	public Set<E> getRelatedPhysicalObjects(E physicalObject);
	
	/**
	 * Get related physical objects of the central object
	 *
	 * @return related physical objects of the central object
	 */
	public Set<E> getRelatedPhysicalObjects();
}