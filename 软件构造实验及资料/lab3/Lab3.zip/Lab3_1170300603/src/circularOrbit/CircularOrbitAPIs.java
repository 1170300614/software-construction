package circularOrbit;

import physicalObject.PhysicalObject;
import track.Track;

import java.util.*;
import java.util.stream.Collectors;

public class CircularOrbitAPIs<L, E> {
	public CircularOrbitAPIs() {}
	
	/**
	 * Get the distribution entropy of the system
	 *
	 * @param c circular orbit system
	 * @return distribution entropy of the system
	 */
	public double getObjectDistributionEntropy(CircularOrbit c) {
		int physicalObjectsSize = c.getPhysicalObjects().size();
		List<Track> tracks = c.getTracks();
		int tracksSize = c.getTracks().size();
		int sum = 0;
		double result = 0;
		if (tracksSize == 0) {
			return 0;
		} else {
			for (Track track: tracks) {
				int size = c.getPhysicalObjectsOnTrack(track).size();
				result += logCombination(physicalObjectsSize - sum, size);
				sum += size;
			}
		}
		return result;
	}
	
	/**
	 * Get the logical distance between two orbit objects
	 *
	 * @param c  current circular orbit system
	 * @param e1 one of the orbit objects
	 * @param e2 another orbit object
	 * @return
	 */
	public int getLogicalDistance(CircularOrbit c, E e1, E e2) {
		if (e1.equals(e2))
			return 0;
		Set<E> physicalObjects = c.getPhysicalObjects();
		if (!physicalObjects.contains(e1) && !physicalObjects.contains(e2)) {
			return -1;
		}
		Map<E, Boolean> visited = new HashMap<>();
		Map<E, Integer> distance = new HashMap<>();
		for (E object: physicalObjects) {
			visited.put(object, false);
			distance.put(object, 0);
		}
		Queue<E> queue = new LinkedList<>();
		queue.add(e1);
		visited.replace(e1, true);
		while (!queue.isEmpty()) {
			E current = queue.poll();
			visited.replace(current, true);
			Set<E> relatedObjects = c.getRelatedPhysicalObjects(current);
			for (E physicalObject: relatedObjects.stream().filter(
					person->!visited.get(person)).collect(Collectors.toSet())) {
				if (physicalObject.equals(e2))
					return distance.get(current) + 1;
				if (!visited.get(physicalObject)) {
					distance.replace(physicalObject, distance.get(current) + 1);
					visited.replace(physicalObject, true);
					queue.add(physicalObject);
				}
			}
		}
		return -1;
	}
	
	/**
	 * Get the physical distance between two orbit objects
	 *
	 * @param system current circular orbit system
	 * @param e1     one of the orbit system
	 * @param e2     another orbit objects
	 * @return
	 */
	public double getPhysicalDistance(CircularOrbit system, PhysicalObject e1, PhysicalObject e2) {
		Set<E> physicalObjects = system.getPhysicalObjects();
		if (physicalObjects.contains(e1) && physicalObjects.contains(e2)) {
			if (e1.equals(e2)) {
				return 0;
			}
			double alpha = Math.toRadians(Math.abs(e1.getAzimuth() - e2.getAzimuth()) % 180);
			return Math.sqrt(system.getRadius(e1) * system.getRadius(e1) +
					                 system.getRadius(e2) * system.getRadius(e2) -
					                 2 * system.getRadius(e1) * system.getRadius((e2)) *
							                 Math.cos(alpha));
		}
		return -1;
	}
	
	/**
	 * Get difference between two circular orbit system
	 *
	 * @param c1 circular orbit system 1
	 * @param c2 circular orbit system 2
	 * @return Difference instance
	 */
	public Difference getDifference(CircularOrbit c1, CircularOrbit c2) {
		return new Difference().getDifference(c1, c2);
	}
	
	/**
	 * @param n int parameter
	 * @return ln(n !), when n is very large, use Stirling formula
	 */
	private double logFactorial(int n) {
		if (n == 0)
			return 0;
		int m = 1;
		if (n >= 1 && n <= 12) {
			for (int i = 1; i <= n; i++) {
				m *= i;
			}
			return Math.log((double) m);
		} else {
			return 0.5 * Math.log(2 * Math.PI * (double) n) +
					(double) n * (Math.log((double) n) - 1);
		}
	}
	
	/**
	 * @param m int parameter
	 * @param n int parameter
	 * @return log(mCr ( m, n))
	 */
	private double logCombination(int m, int n) {
		return logFactorial(m) - logFactorial(n) - logFactorial(m - n);
	}
}