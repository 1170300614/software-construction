package circularOrbit;

import java.util.HashMap;
import java.util.HashSet;
import java.util.Map;
import java.util.Set;

/**
 * Control relations between two physical objects
 *
 * @param <E> PhysicalObject
 */
class PhysicalObjectRelation<E> {
	private Map<E, Set<E>> positivePhysicalObjectRelation = new HashMap<>();
	private Map<E, Set<E>> negativePhysicalObjectRelation = new HashMap<>();
	
	boolean addRelation(E physicalObject_1, E physicalObject_2) {
		if (physicalObject_2 == null) {
			negativePhysicalObjectRelation.put(physicalObject_1, new HashSet<>());
			return true;
		} else if (physicalObject_1 == null) {
			positivePhysicalObjectRelation.put(physicalObject_2, new HashSet<>());
			return true;
		}
		if (!negativePhysicalObjectRelation.containsKey(physicalObject_1) ||
				!positivePhysicalObjectRelation.containsKey(physicalObject_2)) {
			return false;
		} else
			return negativePhysicalObjectRelation.get(physicalObject_1).add(physicalObject_2) &&
					positivePhysicalObjectRelation.get(physicalObject_2).add(physicalObject_1);
	}
	
	boolean removeRelation(E physicalObject_1, E physicalObject_2) {
		if (!negativePhysicalObjectRelation.containsKey(physicalObject_1) ||
				!positivePhysicalObjectRelation.containsKey(physicalObject_2)) {
			return false;
		} else
			return negativePhysicalObjectRelation.get(physicalObject_1).remove(physicalObject_2) &&
					positivePhysicalObjectRelation.get(physicalObject_2).remove(physicalObject_1);
	}
	
	boolean hasRelation(E physicalObject_1, E physicalObject_2) {
		return negativePhysicalObjectRelation.containsKey(physicalObject_1) &&
				positivePhysicalObjectRelation.containsKey(physicalObject_2) &&
				negativePhysicalObjectRelation.get(physicalObject_1).contains(physicalObject_2) &&
				positivePhysicalObjectRelation.get(physicalObject_2).contains(physicalObject_1);
	}
	
	Set<E> getRelatedObjects(E physicalObject) {
		Set<E> relatedObjects = getPositiveObjects(physicalObject);
		relatedObjects.addAll(getNegativeObjects(physicalObject));
		return relatedObjects;
	}
	
	void removeObject(E physicalObject) {
		positivePhysicalObjectRelation.remove(physicalObject);
		negativePhysicalObjectRelation.remove(physicalObject);
	}
	
	private Set<E> getNegativeObjects(E physicalObject) {
		return negativePhysicalObjectRelation.get(physicalObject);
	}
	
	private Set<E> getPositiveObjects(E physicalObject) {
		return positivePhysicalObjectRelation.get(physicalObject);
	}
}