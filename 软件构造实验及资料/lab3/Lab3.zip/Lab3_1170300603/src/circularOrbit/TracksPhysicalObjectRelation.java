package circularOrbit;

import java.util.HashMap;
import java.util.HashSet;
import java.util.Map;
import java.util.Set;

/**
 * Control relation between a track and a physical Object
 *
 * @param <L> Track
 * @param <E> PhysicalObject
 */
public class TracksPhysicalObjectRelation<L, E> implements Relation<L, E> {
	private Map<L, Set<E>> physicalObjectOnTrack = new HashMap<>();
	private Map<E, L> trackOfPhysicalObject = new HashMap<>();
	
	@Override public boolean addRelation(L track, E physicalObject) {
		if (physicalObject == null) {
			physicalObjectOnTrack.put(track, new HashSet<>());
			return true;
		} else if (!physicalObjectOnTrack.containsKey(track)) {
			return false;
		} else {
			trackOfPhysicalObject.putIfAbsent(physicalObject, track);
			return physicalObjectOnTrack.get(track).add(physicalObject);
		}
	}
	
	@Override public boolean removeRelation(L track, E physicalObject) {
		if (!physicalObjectOnTrack.containsKey(track)) {
			return false;
		} else {
			trackOfPhysicalObject.remove(physicalObject);
			return physicalObjectOnTrack.get(track).remove(physicalObject);
		}
	}
	
	@Override public boolean hasRelation(L track, E physicalObject) {
		return physicalObjectOnTrack.containsKey(track) &&
				physicalObjectOnTrack.get(track).contains(physicalObject) &&
				getTrack(physicalObject).equals(track);
	}
	
	boolean transit(E physicalObject, L target) {
		return removeRelation(getTrack(physicalObject), physicalObject) &&
				addRelation(target, physicalObject);
	}
	
	Set<E> getPhysicalObjects(L track) { return physicalObjectOnTrack.get(track); }
	
	L getTrack(E physicalObject) { return trackOfPhysicalObject.get(physicalObject); }
}