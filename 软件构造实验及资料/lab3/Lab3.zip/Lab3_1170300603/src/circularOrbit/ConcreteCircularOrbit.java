package circularOrbit;

import track.Track;

import java.util.HashSet;
import java.util.LinkedList;
import java.util.List;
import java.util.Set;

/**
 * Circular Orbit System
 *
 * @param <L> CentralObject
 * @param <E> PhysicalObject
 */
public class ConcreteCircularOrbit<L, E> extends CircularOrbitAPIs implements CircularOrbit<L, E> {
	private final List<Track> tracks = new LinkedList<>();
	protected final Set<E> physicalObjects = new HashSet<>();
	private L centralObject;
	private final TracksPhysicalObjectRelation<Track, E> tracksPhysicalObjectRelation =
			new TracksPhysicalObjectRelation<>();
	private final CentralPhysicalRelation<L, E> centralPhysicalRelation =
			new CentralPhysicalRelation<>();
	private final PhysicalObjectRelation physicalObjectRelation = new PhysicalObjectRelation<>();
	
	public ConcreteCircularOrbit() {}
	
	private void checkRep() {
	
	}
	
	@Override public List<Track> getTracks() { return tracks; }
	
	@Override public L getCentralObject() { return centralObject; }
	
	@Override public Set<E> getPhysicalObjects() { return physicalObjects; }
	
	@Override public void addTrack(Track track) {
		tracks.add(track);
		tracksPhysicalObjectRelation.addRelation(track, null);
		checkRep();
	}
	
	@Override public boolean removeTrack(Track track) {
		int index = indexOfTrack(track);
		if (index < 0)
			return false;
		Set<E> objects = tracksPhysicalObjectRelation.getPhysicalObjects(track);
		if (objects != null) {
			for (E object: objects) {
				centralPhysicalRelation.removeRelation(centralObject, object);
			}
			for (E physicalObject: physicalObjects) {
				for (E object: objects) {
					physicalObjectRelation.removeRelation(object, physicalObject);
				}
			}
			for (E object: objects) {
				physicalObjects.remove(object);
			}
			for (E object: objects) {
				for (Track oneTrack: tracks) {
					tracksPhysicalObjectRelation.removeRelation(oneTrack, object);
				}
			}
		}
		checkRep();
		return tracks.remove(tracks.get(index));
	}
	
	@Override public void setCentralObject(L centralObject) {
		this.centralObject = centralObject;
		centralPhysicalRelation.addRelation(centralObject, null);
		checkRep();
	}
	
	@Override public boolean addObject(Track target, E physicalObject) {
		if (!tracks.contains(target))
			return false;
		physicalObjects.add(physicalObject);
		physicalObjectRelation.addRelation(physicalObject, null);
		physicalObjectRelation.addRelation(null, physicalObject);
		checkRep();
		return tracksPhysicalObjectRelation.addRelation(target, physicalObject);
	}
	
	@Override public boolean removeObject(E physicalObject) {
		if (!physicalObjects.contains(physicalObject)) {
			return false;
		}
		centralPhysicalRelation.removeRelation(centralObject, physicalObject);
		physicalObjects.remove(physicalObject);
		for (E object: physicalObjects) {
			physicalObjectRelation.removeRelation(physicalObject, object);
		}
		physicalObjectRelation.removeObject(physicalObject);
		for (Track oneTrack: tracks) {
			tracksPhysicalObjectRelation.removeRelation(oneTrack, physicalObject);
		}
		return true;
	}
	
	@Override public boolean addRelationOfCentralPhysical(E physicalObject) {
		return centralPhysicalRelation.addRelation(centralObject, physicalObject);
	}
	
	@Override public boolean addRelationOfPhysicalObject(E physicalObject_1, E physicalObject_2) {
		return physicalObjectRelation.addRelation(physicalObject_1, physicalObject_2);
	}
	
	@Override public boolean hasRelation(E centralObject, Track track) {
		return tracks.contains(track) &&
				tracksPhysicalObjectRelation.hasRelation(track, centralObject);
	}
	
	@Override public boolean hasRelation(E physicalObject) {
		return centralPhysicalRelation.hasRelation(centralObject, physicalObject);
	}
	
	@Override public boolean hasRelation(E physicalObject_1, E physicalObject_2) {
		return physicalObjectRelation.hasRelation(physicalObject_1, physicalObject_2);
	}
	
	@Override public boolean transit(E physicalObject, Track target) {
		if (!tracks.contains(target) && !physicalObjects.contains(physicalObject))
			return false;
		return tracksPhysicalObjectRelation.transit(physicalObject, target);
	}
	
	@Override public double getRadius(E physicalObject) {
		return tracksPhysicalObjectRelation.getTrack(physicalObject).getRadius();
	}
	
	@Override public Set<E> getPhysicalObjectsOnTrack(
			Track track) { return tracksPhysicalObjectRelation.getPhysicalObjects(track);}
	
	@Override public Track getTrackOfObject(E physicalObject) {
		return tracksPhysicalObjectRelation.getTrack(physicalObject);
	}
	
	@Override public Set<E> getRelatedPhysicalObjects(E physicalObject) {
		return physicalObjectRelation.getRelatedObjects(physicalObject);
	}
	
	@Override public Set<E> getRelatedPhysicalObjects() {
		return centralPhysicalRelation.getRelatedObjects(centralObject);
	}
	
	private int indexOfTrack(Track track) {
		for (int i = 0; i < tracks.size(); i++) {
			if (tracks.get(i).equals(track)) {
				return i;
			}
		}
		return -1;
	}
}