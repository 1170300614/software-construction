package centralObject;

import circularOrbit.CircularOrbit;
/**
 * Immutable type
 * Central object
 */
public interface CentralObject {
	/**
	 * Get the label of the physical object
	 *
	 * @return the label
	 */
	String getLabel();
	
	/**
	 * Override equals
	 *
	 * @param physicalObject another physical object
	 * @return if equals
	 */
	boolean equals(CentralObject physicalObject);
	
	/**
	 * Override hashCode
	 *
	 * @return hash code
	 */
	int hashCode();
}