package centralObject;

import circularOrbit.CircularOrbit;

/**
 * The center object of the personal app ecosystem
 */
public class User implements CentralObject{
	private final String name;
	
	private void checkRep() { assert name != null; }
	
	public User(){ this.name = "default"; }
	
	public User(String name) {
		this.name = name;
		checkRep();
	}
	
	public String getLabel() { return name; }
	
	public boolean equals(CentralObject that) {
		if (!(that instanceof User))
			return false;
		User thatPlanet = (User) that;
		return this.getLabel().equals(thatPlanet.getLabel());
	}
	
	@Override
	public int hashCode() { return name.hashCode(); }
}