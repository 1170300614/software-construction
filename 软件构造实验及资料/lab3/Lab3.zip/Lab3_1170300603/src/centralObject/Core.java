package centralObject;

import circularOrbit.CircularOrbit;

/**
 * The center object of the stellar system
 */
public class Core implements CentralObject {
	private final String name;
	
	private void checkRep() { assert name != null; }
	
	public Core(){ this.name = "default"; }
	
	public Core(String name) {
		this.name = name;
		checkRep();
	}
	
	public String getLabel() { return name; }
	
	public boolean equals(CentralObject that) {
		if (!(that instanceof Stellar))
			return false;
		Stellar thatPlanet = (Stellar) that;
		return this.getLabel().equals(thatPlanet.getLabel());
	}
	
	@Override
	public int hashCode() { return name.hashCode(); }
}